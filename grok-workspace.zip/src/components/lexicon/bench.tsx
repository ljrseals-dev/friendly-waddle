import { useEffect, useMemo, useRef, useState } from "react";
import { Copy, Download, TriangleAlert } from "lucide-react";
import { checklistFor } from "@/lib/lexicon/checklist";
import { generateLexicon } from "@/lib/lexicon/generate";
import {
  codepoint,
  FORBIDDEN,
  modeLabel,
  PHONE_GROUPS,
  RAP_EXTRAS,
  SINGING_EXTRAS,
  type Phone,
} from "@/lib/lexicon/inventory";
import { buildFullPrompt } from "@/lib/lexicon/prompts";
import { BATCH_CAP, listWords, reviewLexicon } from "@/lib/lexicon/review";
import { defaultSample, samples } from "@/lib/lexicon/samples";
import { scopeNotes } from "@/lib/lexicon/scope";
import type { Mode } from "@/lib/lexicon/types";
import { cn } from "@/lib/cn";

const STORAGE = "gate-zero-v1";
const CHECKS = "gate-zero-checks-v1";

const MODES: { id: Mode; title: string; detail: string; line: string }[] = [
  {
    id: "g2p",
    title: "Speak",
    detail: "G2P",
    line: "Citation lexicon for a TTS frontend. General American. IPA only.",
  },
  {
    id: "singing",
    title: "Sing",
    detail: "Notes",
    line: "Syllables aligned to beats. Length only on a long monophthong. Alignment is a candidate.",
  },
  {
    id: "rap",
    title: "Rap",
    detail: "Meter",
    line: "Speech stress stays put. Elisions and rhyme class RC:vowel:coda do the performance work.",
  },
];

const PLACEHOLDER: Record<Mode, string> = {
  g2p: "the\nrecord\tNN\nbath\nZephyrielle",
  singing: "day\t0.5,2\nfather\t2,1",
  rap: "every\nsinging\npolice\nking",
};

type Session = {
  mode: Mode;
  words: string;
  output: string;
  worked: boolean;
};

function isMode(value: unknown): value is Mode {
  return value === "g2p" || value === "singing" || value === "rap";
}

export function Bench() {
  const [mode, setMode] = useState<Mode>(defaultSample.mode);
  const [words, setWords] = useState(defaultSample.words);
  const [output, setOutput] = useState(defaultSample.output);
  const [worked, setWorked] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [ready, setReady] = useState(false);
  const [checks, setChecks] = useState<Record<string, boolean>>({});
  const [showAbsent, setShowAbsent] = useState(false);
  const [inspector, setInspector] = useState<Phone>(PHONE_GROUPS[0]?.phones[0] ?? { ipa: "ɡ", name: "script g" });
  const outputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE);
      if (raw) {
        const session = JSON.parse(raw) as Partial<Session>;
        if (isMode(session.mode) && typeof session.words === "string" && typeof session.output === "string") {
          setMode(session.mode);
          setWords(session.words);
          setOutput(session.output);
          setWorked(session.worked !== false);
        }
      }
      const storedChecks = localStorage.getItem(CHECKS);
      if (storedChecks) {
        const parsed = JSON.parse(storedChecks) as Record<string, boolean>;
        if (parsed && typeof parsed === "object") setChecks(parsed);
      }
    } catch {
      /* keep the sample */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    localStorage.setItem(STORAGE, JSON.stringify({ mode, words, output, worked } satisfies Session));
  }, [ready, mode, words, output, worked]);

  useEffect(() => {
    if (!ready) return;
    localStorage.setItem(CHECKS, JSON.stringify(checks));
  }, [ready, checks]);

  const report = useMemo(() => reviewLexicon(mode, output, words), [mode, output, words]);
  const prompt = useMemo(() => buildFullPrompt(mode, words, worked), [mode, words, worked]);
  const count = listWords(words).length;
  const overCap = count > BATCH_CAP;
  const modeCopy = MODES.find((item) => item.id === mode) ?? MODES[0];
  const checksForMode = checklistFor(mode);
  const presentProbes = report.probes.filter((probe) => probe.status !== "absent");
  const visibleProbes = showAbsent ? report.probes : presentProbes;

  const verdict =
    report.stats.entries === 0
      ? "Nothing in the gate"
      : report.blocks > 0
        ? "Do not accept"
        : "Machine gate clear";

  function applySample(id: string) {
    const sample = samples.find((item) => item.id === id);
    if (!sample) return;
    setMode(sample.mode);
    setWords(sample.words);
    setOutput(sample.output);
    setError(null);
    setShowAbsent(false);
  }

  async function copyPrompt() {
    try {
      await navigator.clipboard.writeText(prompt);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setError("Could not copy the prompt.");
    }
  }

  function downloadLexicon() {
    const blob = new Blob([output], { type: "text/tab-separated-values;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `gate-zero-${mode}.tsv`;
    link.click();
    URL.revokeObjectURL(url);
  }

  async function transcribe() {
    if (busy || overCap || count === 0) return;
    setBusy(true);
    setError(null);
    try {
      const result = await generateLexicon({ data: { mode, words, workedExample: worked } });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      setOutput(result.text);
    } catch {
      setError("Transcription did not complete.");
    } finally {
      setBusy(false);
    }
  }

  function insertPhone(phone: Phone) {
    setInspector(phone);
    const el = outputRef.current;
    if (!el) {
      setOutput((prev) => prev + phone.ipa);
      return;
    }
    const start = el.selectionStart ?? output.length;
    const end = el.selectionEnd ?? start;
    const next = output.slice(0, start) + phone.ipa + output.slice(end);
    setOutput(next);
    requestAnimationFrame(() => {
      el.focus();
      const caret = start + phone.ipa.length;
      el.setSelectionRange(caret, caret);
    });
  }

  const banned = FORBIDDEN.filter((phone) => !(mode === "singing" && phone.ipa === "ː"));
  const extras = mode === "singing" ? SINGING_EXTRAS : mode === "rap" ? RAP_EXTRAS : [];

  return (
    <div className="min-h-screen bg-ink text-ivory">
      <header className="border-b border-line">
        <div className="mx-auto flex max-w-6xl flex-col gap-5 px-4 py-5 sm:flex-row sm:items-end sm:justify-between">
          <div className="max-w-xl">
            <p className="text-xs tracking-wide text-brass uppercase">Lexicon 1.0 · IPA</p>
            <h1 className="mt-1 font-display text-4xl leading-none text-ivory">
              Gate <span className="italic text-brass">Zero</span>
            </h1>
            <p className="mt-3 max-w-md text-sm text-mute">
              Three pronunciation lexicons. One declared phone set. A line is not trusted until the gate says so.
            </p>
          </div>
          <div role="tablist" aria-label="Lexicon mode" className="grid grid-cols-3 gap-2 sm:w-80">
            {MODES.map((item) => {
              const on = item.id === mode;
              return (
                <button
                  key={item.id}
                  type="button"
                  role="tab"
                  aria-selected={on}
                  onClick={() => setMode(item.id)}
                  className={cn(
                    "min-h-11 rounded-xl px-3 py-2 text-left transition-opacity duration-200",
                    on ? "bg-brass text-ink" : "bg-paper text-ivory ring-desk",
                  )}
                >
                  <span className="block font-display text-lg leading-none">{item.title}</span>
                  <span className={cn("mt-1 block text-xs", on ? "opacity-70" : "text-mute")}>{item.detail}</span>
                </button>
              );
            })}
          </div>
        </div>
      </header>

      <main className="mx-auto grid max-w-6xl gap-6 px-4 py-6 lg:grid-cols-12">
        <div className="flex flex-col gap-6 lg:col-span-7">
          <p className="text-sm text-mute">{modeCopy.line}</p>
          <p className="text-sm text-mute">
            Engine <span className="text-ivory">IPA, espeak-ng aligned</span>. Larynx and ARPAbet stay deferred until a
            substitution table is named.
          </p>

          <section className="rounded-2xl bg-paper p-4 ring-desk sm:p-5">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <h2 className="font-display text-2xl">
                <span className="mr-2 text-brass">01</span>List
              </h2>
              <p className={cn("text-sm tabular-nums", overCap ? "text-brass" : "text-mute")}>
                {count} / {BATCH_CAP}
              </p>
            </div>
            <p className="mt-2 text-sm text-mute">
              One word a line. An optional second column is a tab: part of speech, beat durations, or a meter hint.
            </p>
            <label className="mt-4 block text-sm text-mute" htmlFor="word-list">
              Word list
              <textarea
                id="word-list"
                value={words}
                onChange={(event) => setWords(event.target.value)}
                placeholder={PLACEHOLDER[mode]}
                spellCheck={false}
                className="mt-2 min-h-32 w-full resize-y px-3 py-3 text-sm leading-relaxed text-ivory placeholder:text-mute"
              />
            </label>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <label className="min-w-40 flex-1 text-sm text-mute">
                <span className="sr-only">Load a sample batch</span>
                <select
                  className="h-11 w-full px-3 text-sm text-ivory"
                  defaultValue=""
                  onChange={(event) => {
                    applySample(event.target.value);
                    event.currentTarget.value = "";
                  }}
                >
                  <option value="">Load a sample…</option>
                  {samples.map((sample) => (
                    <option key={sample.id} value={sample.id}>
                      {sample.label}
                    </option>
                  ))}
                </select>
              </label>
              <button
                type="button"
                onClick={() => {
                  setWords("");
                  setOutput("");
                  setError(null);
                }}
                className="h-11 rounded-lg bg-raised px-4 text-sm text-ivory ring-desk"
              >
                Clear
              </button>
            </div>
            {overCap ? (
              <p className="mt-3 text-sm text-brass">
                Past {BATCH_CAP} lines the uncertain rate swamps review. Use espeak-ng or Phonetisaurus as the base, and
                the model only on the OOV tail.
              </p>
            ) : null}
          </section>

          <section className="rounded-2xl bg-paper p-4 ring-desk sm:p-5">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <h2 className="font-display text-2xl">
                <span className="mr-2 text-brass">02</span>Transcript
              </h2>
              <p className="text-sm text-mute tabular-nums">{report.stats.entries} rows</p>
            </div>
            <p className="mt-2 text-sm text-mute">
              Paste a model’s lexicon, or transcribe this list. Output is tab-separated, then a #VALIDATION block.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              <button
                type="button"
                onClick={transcribe}
                disabled={busy || overCap || count === 0}
                className="h-11 rounded-lg bg-brass px-4 text-sm font-medium text-ink disabled:opacity-40"
              >
                {busy ? "Transcribing…" : "Transcribe batch"}
              </button>
              <button
                type="button"
                onClick={copyPrompt}
                className="inline-flex h-11 items-center gap-2 rounded-lg bg-raised px-4 text-sm text-ivory ring-desk"
              >
                <Copy className="size-4" aria-hidden="true" />
                {copied ? "Copied" : "Copy prompt"}
              </button>
              <button
                type="button"
                onClick={downloadLexicon}
                disabled={!output.trim()}
                className="inline-flex h-11 items-center gap-2 rounded-lg bg-raised px-4 text-sm text-ivory ring-desk disabled:opacity-40"
              >
                <Download className="size-4" aria-hidden="true" />
                Download
              </button>
            </div>
            <label className="mt-4 flex min-h-11 items-start gap-3 text-sm text-ivory">
              <input
                type="checkbox"
                checked={worked}
                onChange={(event) => setWorked(event.target.checked)}
                className="mt-1 size-4 accent-brass"
              />
              <span>
                Include a worked example in the prompt. Use this when a model keeps emitting ː, ʰ, or ̩.
              </span>
            </label>
            {error ? (
              <p role="alert" className="mt-3 flex items-start gap-2 text-sm text-brass">
                <TriangleAlert className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
                {error}
              </p>
            ) : null}
            <label className="mt-4 block text-sm text-mute" htmlFor="lexicon-output">
              Lexicon
              <textarea
                id="lexicon-output"
                ref={outputRef}
                value={output}
                onChange={(event) => setOutput(event.target.value)}
                spellCheck={false}
                className="mt-2 min-h-48 w-full resize-y px-3 py-3 text-sm leading-relaxed text-ivory"
              />
            </label>
            <details className="mt-4">
              <summary className="flex min-h-11 items-center text-sm text-ivory">Assembled prompt</summary>
              <pre className="mt-2 max-h-80 overflow-auto rounded-lg bg-ink p-3 text-sm leading-relaxed whitespace-pre-wrap text-mute">
                {prompt}
              </pre>
            </details>
          </section>

          <section className="rounded-2xl bg-paper p-4 ring-desk sm:p-5">
            <h2 className="font-display text-2xl">
              <span className="mr-2 text-brass">03</span>Inventory
            </h2>
            <p className="mt-2 text-sm text-ivory">
              <span className="font-medium">{inspector.ipa}</span>{" "}
              <span className="text-mute">
                {codepoint(inspector.ipa)} — {inspector.name}
              </span>
            </p>
            <p className="mt-1 text-sm text-mute">Click a phone to drop the real character into the transcript. ASCII g and r are not in the set.</p>
            <div className="mt-4 flex flex-col gap-4">
              {PHONE_GROUPS.map((group) => (
                <PhoneRow
                  key={group.id}
                  label={group.label}
                  phones={group.phones}
                  active={inspector.ipa}
                  onPick={insertPhone}
                />
              ))}
              {extras.length > 0 ? (
                <PhoneRow
                  label={mode === "singing" ? "Singing marks" : "Rap marks"}
                  phones={extras}
                  active={inspector.ipa}
                  onPick={insertPhone}
                />
              ) : null}
              <PhoneRow
                label="Banned"
                phones={banned}
                active={inspector.ipa}
                onPick={(phone) => setInspector(phone)}
              />
            </div>
          </section>

          <section className="rounded-2xl bg-paper p-4 ring-desk sm:p-5">
            <h2 className="font-display text-2xl">Out of scope</h2>
            <div className="mt-4 flex flex-col gap-4">
              {scopeNotes.map((note) => (
                <div key={note.title}>
                  <h3 className="text-sm font-medium text-ivory">{note.title}</h3>
                  <p className="mt-1 text-sm text-mute">{note.body}</p>
                </div>
              ))}
            </div>
          </section>
        </div>

        <aside className="lg:col-span-5">
          <div className="flex flex-col gap-4 lg:sticky lg:top-4">
            <section className="rounded-2xl bg-paper p-4 ring-desk sm:p-5" aria-live="polite">
              <p className="text-xs tracking-wide text-brass uppercase">{modeLabel(mode)} review</p>
              <h2 className="mt-1 font-display text-3xl">{verdict}</h2>
              <p className="mt-2 text-sm text-mute">
                {report.blocks} blocking · {report.warns} to check · {report.findings.length - report.blocks - report.warns} notes.
                The machine gate is not the whole review.
              </p>
              <dl className="mt-4 grid grid-cols-2 gap-px overflow-hidden rounded-xl bg-line sm:grid-cols-4">
                <Stat label="Blocks" value={String(report.blocks)} hot={report.blocks > 0} />
                <Stat label="Outside set" value={String(report.stats.inventoryViolations)} hot={report.stats.inventoryViolations > 0} />
                <Stat label="OOV" value={String(report.stats.oov)} />
                <Stat
                  label={mode === "rap" ? "Elision" : mode === "singing" ? "Melisma" : "Alt"}
                  value={
                    mode === "rap"
                      ? report.stats.elisionCoverage == null
                        ? "—"
                        : report.stats.elisionCoverage.toFixed(2)
                      : mode === "singing"
                        ? String(report.stats.melisma)
                        : String(report.stats.alt)
                  }
                />
              </dl>
              {mode === "rap" && report.stats.multisyllabic > 0 ? (
                <p className="mt-3 text-sm text-mute">
                  Elision coverage {report.stats.elidedMultisyllabic}/{report.stats.multisyllabic} multisyllabic rows.
                  Gate is 0.80.
                </p>
              ) : null}
            </section>

            <section className="rounded-2xl bg-paper ring-desk">
              <div className="px-4 pt-4 sm:px-5">
                <h3 className="font-display text-xl">Findings</h3>
              </div>
              <ul className="mt-2 max-h-96 overflow-auto">
                {report.findings.length === 0 ? (
                  <li className="px-4 py-4 text-sm text-mute sm:px-5">No findings.</li>
                ) : (
                  report.findings.map((finding, index) => (
                    <li key={`${finding.code}-${finding.line ?? "x"}-${index}`} className="border-t border-line px-4 py-3 sm:px-5">
                      <div className="flex items-baseline justify-between gap-3">
                        <span
                          className={cn(
                            "text-xs tracking-wide uppercase",
                            finding.severity === "block" ? "text-brass" : "text-mute",
                          )}
                        >
                          {finding.severity === "block" ? "Block" : finding.severity === "warn" ? "Check" : "Note"}
                          <span className="ml-2 normal-case tracking-normal">{finding.code}</span>
                        </span>
                        {finding.line ? (
                          <span className="text-xs text-mute tabular-nums">Line {finding.line}</span>
                        ) : null}
                      </div>
                      <p className="mt-1 text-sm text-ivory">{finding.message}</p>
                    </li>
                  ))
                )}
              </ul>
            </section>

            <section className="rounded-2xl bg-paper p-4 ring-desk sm:p-5">
              <div className="flex items-baseline justify-between gap-3">
                <h3 className="font-display text-xl">Gate 0</h3>
                <p className="text-sm text-mute tabular-nums">
                  {presentProbes.filter((probe) => probe.status === "match").length}/{presentProbes.length || 0} in batch
                </p>
              </div>
              <p className="mt-2 text-sm text-mute">
                Twenty frequent words, inventory-normalized General American. This is a convention reference, not a live
                espeak-ng process. A mismatch is a diff to judge, not an automatic reject.
              </p>
              {presentProbes.length === 0 ? (
                <p className="mt-3 text-sm text-ivory">None of the probes are in this batch.</p>
              ) : null}
              <ul className="mt-3 flex flex-col gap-2">
                {visibleProbes.map((probe) => (
                  <li key={probe.word} className="grid grid-cols-3 items-baseline gap-2 text-sm">
                    <span className="text-ivory">{probe.word}</span>
                    <span className={cn(probe.status === "diverge" ? "text-brass" : "text-ivory")}>
                      {probe.status === "absent" ? "—" : probe.actual}
                    </span>
                    <span className="text-mute">
                      {probe.expected}
                      <span className="ml-2 text-xs uppercase">
                        {probe.status === "match" ? "match" : probe.status === "diverge" ? "differs" : "absent"}
                      </span>
                    </span>
                  </li>
                ))}
              </ul>
              <button
                type="button"
                onClick={() => setShowAbsent((value) => !value)}
                className="mt-3 min-h-11 text-sm text-brass"
              >
                {showAbsent ? "Hide absent probes" : "Show absent probes"}
              </button>
            </section>

            <section className="rounded-2xl bg-paper p-4 ring-desk sm:p-5">
              <h3 className="font-display text-xl">Still on you</h3>
              <p className="mt-2 text-sm text-mute">The bench cannot see a dictionary. These stay human.</p>
              <ul className="mt-2">
                {checksForMode.map((item) => (
                  <li key={item.id}>
                    <label className="flex min-h-11 items-start gap-3 py-2">
                      <input
                        type="checkbox"
                        checked={Boolean(checks[item.id])}
                        onChange={(event) =>
                          setChecks((prev) => ({ ...prev, [item.id]: event.target.checked }))
                        }
                        className="mt-1 size-4 shrink-0 accent-brass"
                      />
                      <span className="text-sm text-ivory">{item.text}</span>
                    </label>
                  </li>
                ))}
              </ul>
            </section>
          </div>
        </aside>
      </main>
    </div>
  );
}

function Stat({ label, value, hot = false }: { label: string; value: string; hot?: boolean }) {
  return (
    <div className="bg-paper px-3 py-3">
      <dt className="text-xs text-mute">{label}</dt>
      <dd className={cn("mt-1 font-display text-2xl tabular-nums", hot ? "text-brass" : "text-ivory")}>{value}</dd>
    </div>
  );
}

function PhoneRow({
  label,
  phones,
  active,
  onPick,
}: {
  label: string;
  phones: Phone[];
  active: string;
  onPick: (phone: Phone) => void;
}) {
  return (
    <div>
      <h3 className="text-sm text-mute">{label}</h3>
      <div className="mt-2 flex flex-wrap gap-2">
        {phones.map((phone) => {
          const on = phone.ipa === active;
          return (
            <button
              key={`${label}-${phone.ipa}`}
              type="button"
              onClick={() => onPick(phone)}
              aria-pressed={on}
              className={cn(
                "flex h-11 min-w-11 items-center justify-center rounded-lg px-2 text-lg",
                on ? "bg-brass text-ink" : "bg-ink text-ivory ring-desk",
              )}
            >
              {phone.ipa}
            </button>
          );
        })}
      </div>
    </div>
  );
}

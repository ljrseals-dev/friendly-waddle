import type { Mode } from "./types.ts";

export type CheckItem = { id: string; text: string };

const SHARED: CheckItem[] = [
  {
    id: "oov-real",
    text: "Every #OOV is genuinely unknown. Names and novel forms should dominate. A common word here means the model is refusing too hard.",
  },
  {
    id: "uncertain",
    text: "Read each #UNCERTAIN line against a dictionary. If they are more than 20% of a curated list, fix the prompt or the list before going on.",
  },
  {
    id: "alt",
    text: "Every #ALT is attested, not invented. The primary is the more frequent reading.",
  },
  {
    id: "pos",
    text: "Each POS-tagged homograph has its readings, and the primary matches ordinary frequency.",
  },
  {
    id: "rp",
    text: "RP flags are real GA/RP splits. Spot-check bath, dance, trap, lot, thought, nurse, goose.",
  },
];

const SINGING: CheckItem[] = [
  {
    id: "melisma",
    text: "Every #MELISMA_RISK writes a coloration in the segment. A bare flag is not done.",
  },
  {
    id: "stress",
    text: "#STRESS_CONFLICT keeps speech stress in the syllable column. The melody does not get to move it silently.",
  },
  {
    id: "aligner",
    text: "Note alignment is a candidate. Reconcile it with a deterministic aligner — note count against syllable count.",
  },
];

const RAP: CheckItem[] = [
  {
    id: "rhyme",
    text: "Shared rhyme classes are intentional. Do not let cot and caught collapse in a dialect that keeps them apart.",
  },
  {
    id: "dialect",
    text: "Dialect tags name a variety. “Non-standard” is not a variety.",
  },
  {
    id: "taxonomy",
    text: "RC:<vowel>:<coda> is a working invention, lexicon v1.0. It is not a published standard. Version it if you change it.",
  },
];

export function checklistFor(mode: Mode): CheckItem[] {
  if (mode === "singing") return [...SHARED, ...SINGING];
  if (mode === "rap") return [...SHARED, ...RAP];
  return SHARED;
}

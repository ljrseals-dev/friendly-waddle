/**
 * Gate 0 probes. Inventory-normalized General American citation/function-word
 * forms — a convention reference, not a live espeak-ng process. Divergences
 * are diffs to adjudicate, not automatic rejects.
 */
export const GATE0: { word: string; ipa: string; note: string }[] = [
  { word: "the", ipa: "ðə", note: "Unstressed function word. ði before a vowel is the alt." },
  { word: "of", ipa: "əv", note: "Unstressed. ʌv is the strong form." },
  { word: "and", ipa: "ænd", note: "Full form. ən is a reduction, and syllabic n is forbidden." },
  { word: "to", ipa: "tə", note: "Unstressed. tu before a vowel is the alt." },
  { word: "a", ipa: "ə", note: "Unstressed article. eɪ is the letter name, not the word." },
  { word: "in", ipa: "ɪn", note: "Citation form." },
  { word: "is", ipa: "ɪz", note: "Citation form." },
  { word: "you", ipa: "ju", note: "Citation form." },
  { word: "that", ipa: "ðæt", note: "Strong form of the demonstrative and complementizer." },
  { word: "it", ipa: "ɪt", note: "Citation form." },
  { word: "he", ipa: "hi", note: "Citation form. hi is not i." },
  { word: "was", ipa: "wʌz", note: "Strong form. wəz is the reduction." },
  { word: "for", ipa: "fɚ", note: "Rhotic schwa. Not fɔɹ and not fə." },
  { word: "on", ipa: "ɑn", note: "GA lot vowel. ɔn is the non-merged alt." },
  { word: "are", ipa: "ɑɹ", note: "Strong form. Unstressed ɚ is the reduction." },
  { word: "as", ipa: "æz", note: "Strong form. əz is the reduction." },
  { word: "with", ipa: "wɪð", note: "Voiced ð is the GA default here. wɪθ is attested." },
  { word: "his", ipa: "hɪz", note: "Citation form." },
  { word: "they", ipa: "ðeɪ", note: "Citation form." },
  { word: "i", ipa: "aɪ", note: "The pronoun. Orthography I or i." },
];

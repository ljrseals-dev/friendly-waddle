import { GATE0 } from "./gate.ts";
import { MONOPHTHONGS, tokenize } from "./inventory.ts";
import type { Finding, GateProbe, Mode, ReviewReport, ReviewStats } from "./types.ts";

export const BATCH_CAP = 40;

const FLAG_SPEC: Record<Mode, Record<string, "bare" | "value">> = {
  g2p: {
    OOV: "bare",
    UNCERTAIN: "bare",
    ALT: "value",
    POS: "value",
    RP: "bare",
    MULTIWORD: "bare",
  },
  singing: {
    OOV: "bare",
    UNCERTAIN: "bare",
    ELISION: "value",
    CONSONANT_PLACEMENT: "value",
    MELISMA_RISK: "bare",
    STRESS_CONFLICT: "bare",
  },
  rap: {
    OOV: "bare",
    UNCERTAIN: "bare",
    METER_FIT: "value",
    STRESS_SHIFT: "bare",
    HOMOPHONE_RHYME: "value",
    DIALECT: "value",
  },
};

const VAGUE_DIALECT = new Set([
  "non-standard",
  "nonstandard",
  "other",
  "dialect",
  "regional",
  "unknown",
  "various",
  "n/a",
]);

const REQUIRED_KEYS: Record<Mode, string[]> = {
  g2p: ["INVENTORY_VIOLATIONS", "OOV_COUNT", "UNCERTAIN_COUNT", "ALT_COUNT", "POS_COLLISIONS"],
  singing: [
    "INVENTORY_VIOLATIONS",
    "OOV_COUNT",
    "UNCERTAIN_COUNT",
    "ELISION_COUNT",
    "MELISMA_RISK_COUNT",
    "NOTE_TOTAL_CHECK",
  ],
  rap: [
    "INVENTORY_VIOLATIONS",
    "OOV_COUNT",
    "UNCERTAIN_COUNT",
    "DIALECT_COUNT",
    "RHYME_CLASS_COLLISIONS",
    "ELISION_COVERAGE",
  ],
};

const PROSE_KEYS = new Set(["POS_COLLISIONS", "NOTE_TOTAL_CHECK", "RHYME_CLASS_COLLISIONS"]);

type Flag = { raw: string; name: string; value?: string };

type Entry = {
  line: number;
  word: string;
  cols: string[];
  flags: Flag[];
};

type PhoneWhere = "phonemes" | "syllables" | "notes" | "elision" | "alt" | "rhyme";

type Hint = { pos?: string; beats?: number[] };

function columnsFor(mode: Mode): number {
  if (mode === "g2p") return 3;
  if (mode === "singing") return 4;
  return 5;
}

function splitFlags(field: string): Flag[] {
  const trimmed = field.trim();
  if (!trimmed || trimmed === "-") return [];
  return trimmed
    .split(",")
    .map((part) => {
      const raw = part.trim();
      const body = raw.startsWith("#") ? raw.slice(1) : raw;
      const colon = body.indexOf(":");
      if (colon === -1) return { raw, name: body };
      return { raw, name: body.slice(0, colon), value: body.slice(colon + 1) };
    })
    .filter((flag) => flag.name.length > 0);
}

function hasFlag(flags: Flag[], name: string): boolean {
  return flags.some((flag) => flag.name === name);
}

function syllableCount(phonemes: string): number {
  const trimmed = phonemes.trim();
  if (!trimmed || trimmed === "?" || trimmed === "-") return 0;
  return trimmed
    .split(".")
    .map((part) => part.trim())
    .filter(Boolean).length;
}

function phoneFindings(
  text: string,
  mode: Mode,
  line: number,
  where: PhoneWhere,
  beats: number | null,
  melisma: boolean,
): Finding[] {
  const trimmed = text.trim();
  if (!trimmed || trimmed === "?" || trimmed === "-" || trimmed === "∅") return [];
  const tokens = tokenize(trimmed, mode);
  const findings: Finding[] = [];
  tokens.forEach((token, index) => {
    if (token.kind === "bad") {
      findings.push({
        severity: "block",
        code: "INV",
        line,
        message: `${where}: ${token.detail}`,
      });
      return;
    }
    if (token.value !== "ː" && token.value !== "a" && token.value !== "ə") return;
    const prev = tokens[index - 1];
    const next = tokens[index + 1];
    if (token.value === "ː") {
      if (where !== "notes") {
        findings.push({
          severity: "block",
          code: "LENGTH",
          line,
          message: "ː is only legal inside a singing note segment, on a monophthong held at least 2 beats",
        });
        return;
      }
      const prevValue = prev?.kind === "phone" ? prev.value : undefined;
      if (!prevValue || !MONOPHTHONGS.has(prevValue)) {
        findings.push({
          severity: melisma ? "warn" : "block",
          code: "LENGTH",
          line,
          message: melisma
            ? "ː does not follow a monophthong. Melisma is flagged — confirm the coloration is the one you want."
            : "ː must follow a monophthong. A diphthong needs #MELISMA_RISK and the coloration written in the segment.",
        });
      } else if (beats != null && beats < 2) {
        findings.push({
          severity: "block",
          code: "LENGTH",
          line,
          message: `ː on a ${beats}-beat note — length is only for a hold of at least 2 beats`,
        });
      }
    }
    if (token.value === "a" && mode === "singing") {
      const tied =
        (prev?.kind === "phone" && prev.value === "‿") ||
        (next?.kind === "phone" && next.value === "‿");
      if (!tied && !melisma) {
        findings.push({
          severity: "warn",
          code: "BARE_A",
          line,
          message: "Bare a is only a tie-split of aɪ or aʊ. It is not a general vowel.",
        });
      }
    }
    if (token.value === "ə" && next?.kind === "phone" && next.value === "ɹ") {
      findings.push({
        severity: "warn",
        code: "RHOTIC",
        line,
        message: "Sequence əɹ. The inventory note says use ɚ or ɝ, not əɹ.",
      });
    }
  });
  return findings;
}

type NoteSeg = { phones: string; beats: number };

function parseNotes(field: string): { segments: NoteSeg[]; error?: string } {
  const trimmed = field.trim();
  if (!trimmed || trimmed === "?" || trimmed === "-") return { segments: [] };
  const re = /(\d+):([^:]+):(\d+(?:\.\d+)?)/g;
  const segments: NoteSeg[] = [];
  let last = 0;
  let match: RegExpExecArray | null;
  while ((match = re.exec(trimmed))) {
    const between = trimmed.slice(last, match.index);
    if (between && !/^[\s;|,]+$/.test(between)) {
      return { segments, error: `Note alignment breaks near “${between.trim()}”` };
    }
    segments.push({ phones: match[2], beats: Number(match[3]) });
    last = match.index + match[0].length;
  }
  const tail = trimmed.slice(last);
  if (tail && !/^[\s;|,]+$/.test(tail)) {
    return { segments, error: `Note alignment has a tail the bench cannot read: “${tail.trim()}”` };
  }
  if (segments.length === 0) {
    return { segments, error: "Note alignment must look like 1:kæt:1;2:s:0.5" };
  }
  return { segments };
}

function parseHints(text: string, mode: Mode): Map<string, Hint> {
  const hints = new Map<string, Hint>();
  for (const line of text.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const [rawWord, ...rest] = trimmed.split("\t");
    const word = rawWord.trim().toLowerCase();
    if (!word) continue;
    const extra = rest.join("\t").trim();
    const hint: Hint = {};
    if (mode === "g2p" && extra) hint.pos = extra;
    if (mode === "singing" && extra && /^[\d.\s,+/]+$/.test(extra)) {
      const beats = extra
        .split(/[\s,+/]+/)
        .filter(Boolean)
        .map(Number);
      if (beats.length > 0 && beats.every((n) => Number.isFinite(n))) hint.beats = beats;
    }
    hints.set(word, hint);
  }
  return hints;
}

export function listWords(text: string): string[] {
  return text
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => line && !line.startsWith("#"))
    .map((line) => line.split("\t")[0]?.trim() ?? "")
    .filter(Boolean);
}

function validationStart(line: string): boolean {
  const trimmed = line.trim();
  if (trimmed === "#VALIDATION") return true;
  return /^#(INVENTORY_VIOLATIONS|OOV_COUNT|UNCERTAIN_COUNT|ALT_COUNT|POS_COLLISIONS|ELISION_COUNT|MELISMA_RISK_COUNT|NOTE_TOTAL_CHECK|DIALECT_COUNT|RHYME_CLASS_COLLISIONS|ELISION_COVERAGE)\b/.test(
    trimmed,
  );
}

function emptyStats(): ReviewStats {
  return {
    entries: 0,
    inventoryViolations: 0,
    oov: 0,
    uncertain: 0,
    alt: 0,
    elision: 0,
    melisma: 0,
    dialect: 0,
    multisyllabic: 0,
    elidedMultisyllabic: 0,
    elisionCoverage: null,
    validationPresent: false,
  };
}

function finish(mode: Mode, findings: Finding[], stats: ReviewStats, probes: GateProbe[]): ReviewReport {
  const rank: Record<Finding["severity"], number> = { block: 0, warn: 1, note: 2 };
  findings.sort((a, b) => rank[a.severity] - rank[b.severity] || (a.line ?? 0) - (b.line ?? 0));
  return {
    mode,
    findings,
    stats,
    probes,
    blocks: findings.filter((f) => f.severity === "block").length,
    warns: findings.filter((f) => f.severity === "warn").length,
  };
}

function inspectRhyme(field: string, line: number): { findings: Finding[]; tags: string[] } {
  const trimmed = field.trim();
  if (!trimmed || trimmed === "-" || trimmed === "?") return { findings: [], tags: [] };
  const findings: Finding[] = [];
  const tags: string[] = [];
  for (const tag of trimmed.split(",").map((part) => part.trim()).filter(Boolean)) {
    const match = /^RC:([^:\s]+):([^:\s]+)$/.exec(tag);
    if (!match) {
      findings.push({
        severity: "block",
        code: "RHYME",
        line,
        message: `Rhyme class “${tag}” is not RC:<vowel-set>:<coda>. Open coda is ∅.`,
      });
      continue;
    }
    tags.push(tag);
    if (match[1] !== "∅") {
      findings.push(...phoneFindings(match[1], "rap", line, "rhyme", null, false));
    }
    if (match[2] !== "∅") {
      findings.push(...phoneFindings(match[2], "rap", line, "rhyme", null, false));
    }
  }
  return { findings, tags };
}

function numbersMatch(declared: string, actual: number): boolean {
  const value = Number(declared.trim());
  return Number.isFinite(value) && value === actual;
}

function coverageMatch(declared: string, actual: number): boolean {
  const fraction = declared.trim().match(/^(\d+)\s*\/\s*(\d+)$/);
  const value = fraction
    ? Number(fraction[2]) === 0
      ? NaN
      : Number(fraction[1]) / Number(fraction[2])
    : Number(declared.trim());
  return Number.isFinite(value) && Math.abs(value - actual) <= 0.02;
}

export function reviewLexicon(mode: Mode, output: string, words: string): ReviewReport {
  const findings: Finding[] = [];
  const probes: GateProbe[] = [];
  const stats = emptyStats();
  const text = output.replace(/^\uFEFF/, "").replace(/\r\n/g, "\n").replace(/\r/g, "\n");

  if (!text.trim()) {
    findings.push({
      severity: "note",
      code: "EMPTY",
      message: "Nothing to review yet. Load a sample, paste a lexicon, or transcribe the list.",
    });
    return finish(mode, findings, stats, probes);
  }

  const hints = parseHints(words, mode);
  const lines = text.split("\n");
  let inValidation = false;
  const declared: Record<string, string> = {};
  const entries: Entry[] = [];
  const expected = columnsFor(mode);

  for (let index = 0; index < lines.length; index += 1) {
    const raw = lines[index] ?? "";
    const trimmed = raw.trim();
    if (!trimmed) continue;
    if (!inValidation && validationStart(trimmed)) {
      inValidation = true;
      stats.validationPresent = true;
    }
    if (inValidation) {
      if (trimmed === "#VALIDATION") continue;
      const key = /^#([A-Z0-9_]+)\s*:\s*(.*)$/.exec(trimmed);
      if (key) declared[key[1]] = key[2].trim();
      continue;
    }
    if (!raw.includes("\t")) {
      findings.push({
        severity: "block",
        code: "FORMAT",
        line: index + 1,
        message: "Expected tab-separated columns. Spaces do not count.",
      });
      continue;
    }
    const cols = raw.replace(/\t+$/g, "").split("\t").map((col) => col.trim());
    if (cols.length !== expected) {
      findings.push({
        severity: "block",
        code: "FORMAT",
        line: index + 1,
        message: `${modeLabelColumns(mode)} needs ${expected} tab-separated columns; this line has ${cols.length}.`,
      });
      continue;
    }
    if ((cols[0] ?? "").toLowerCase() === "word") continue;
    entries.push({
      line: index + 1,
      word: cols[0] ?? "",
      cols,
      flags: splitFlags(cols[expected - 1] ?? ""),
    });
  }

  stats.entries = entries.length;
  if (entries.length === 0) {
    findings.push({
      severity: "warn",
      code: "EMPTY",
      message: "No lexicon rows. The validation block, if any, has nothing under it.",
    });
  }

  const spec = FLAG_SPEC[mode];
  const byWord = new Map<string, Entry[]>();
  const rhymeOwners = new Map<string, string[]>();

  for (const entry of entries) {
    const key = entry.word.toLowerCase();
    const group = byWord.get(key) ?? [];
    group.push(entry);
    byWord.set(key, group);

    for (const flag of entry.flags) {
      const kind = spec[flag.name];
      if (!kind) {
        findings.push({
          severity: "warn",
          code: "FLAG",
          line: entry.line,
          message: `#${flag.name} is not a ${mode} flag.`,
        });
        continue;
      }
      if (kind === "value" && !flag.value?.trim()) {
        findings.push({
          severity: "warn",
          code: "FLAG",
          line: entry.line,
          message: `#${flag.name} needs a value after the colon.`,
        });
      }
      if (kind === "bare" && flag.value != null) {
        findings.push({
          severity: "warn",
          code: "FLAG",
          line: entry.line,
          message: `#${flag.name} does not take a value.`,
        });
      }
    }

    if (hasFlag(entry.flags, "OOV")) stats.oov += 1;
    if (hasFlag(entry.flags, "UNCERTAIN")) stats.uncertain += 1;
    stats.alt += entry.flags.filter((flag) => flag.name === "ALT").length;
    stats.elision += entry.flags.filter((flag) => flag.name === "ELISION").length;
    if (hasFlag(entry.flags, "MELISMA_RISK")) stats.melisma += 1;
    if (hasFlag(entry.flags, "DIALECT")) stats.dialect += 1;

    const melisma = hasFlag(entry.flags, "MELISMA_RISK");
    const oov = hasFlag(entry.flags, "OOV");
    const phonemes = entry.cols[1] ?? "";

    if (oov) {
      const bad: string[] = [];
      if (phonemes.trim() !== "?") bad.push("phonemes");
      if (mode === "singing" && (entry.cols[2] ?? "").trim() !== "?") bad.push("note alignment");
      if (mode === "rap" && !["?", "-"].includes((entry.cols[2] ?? "").trim())) {
        findings.push({
          severity: "warn",
          code: "OOV",
          line: entry.line,
          message: "OOV rap row should put ? in the rhyme column rather than a guessed class.",
        });
      }
      if (bad.length > 0) {
        findings.push({
          severity: "block",
          code: "OOV_PHONES",
          line: entry.line,
          message: `#OOV must not carry a transcription. Put ? in ${bad.join(" and ")}.`,
        });
      }
    } else if (phonemes.trim() === "?") {
      findings.push({
        severity: "block",
        code: "OOV_PHONES",
        line: entry.line,
        message: "Phoneme field is ? but the row has no #OOV flag.",
      });
    }

    if (mode === "g2p") {
      findings.push(...phoneFindings(phonemes, mode, entry.line, "phonemes", null, false));
      for (const flag of entry.flags) {
        if (flag.name === "ALT" && flag.value) {
          findings.push(...phoneFindings(flag.value, mode, entry.line, "alt", null, false));
        }
      }
      if (entry.word.includes("_") && !hasFlag(entry.flags, "MULTIWORD")) {
        findings.push({
          severity: "warn",
          code: "MULTIWORD",
          line: entry.line,
          message: "Underscore marks a multiword entry. Add #MULTIWORD.",
        });
      }
      const hint = hints.get(key);
      if (hint?.pos && !hasFlag(entry.flags, "POS")) {
        findings.push({
          severity: "warn",
          code: "POS",
          line: entry.line,
          message: `Word list supplied a POS hint (${hint.pos}) but the row has no #POS flag.`,
        });
      }
    }

    if (mode === "singing") {
      findings.push(...phoneFindings(phonemes, mode, entry.line, "syllables", null, melisma));
      if (!oov) {
        const parsed = parseNotes(entry.cols[2] ?? "");
        if (parsed.error) {
          findings.push({
            severity: "block",
            code: "ALIGN",
            line: entry.line,
            message: parsed.error,
          });
        }
        let sum = 0;
        for (const segment of parsed.segments) {
          sum += segment.beats;
          findings.push(
            ...phoneFindings(segment.phones, mode, entry.line, "notes", segment.beats, melisma),
          );
        }
        const hint = hints.get(key);
        if (hint?.beats && parsed.segments.length > 0) {
          const expectedSum = hint.beats.reduce((total, beat) => total + beat, 0);
          if (Math.abs(sum - expectedSum) > 0.051) {
            findings.push({
              severity: "block",
              code: "NOTE_SUM",
              line: entry.line,
              message: `Note durations sum to ${trimNum(sum)}, the word list asked for ${trimNum(expectedSum)}.`,
            });
          }
        }
        if (melisma) {
          const colored = parsed.segments.some((segment) => /[ː‿a]/.test(segment.phones));
          if (!colored) {
            findings.push({
              severity: "warn",
              code: "MELISMA",
              line: entry.line,
              message: "#MELISMA_RISK is bare. Write the coloration in the note segment (a‿ɪ, aːɪ, or similar).",
            });
          }
        }
      }
      for (const flag of entry.flags) {
        if (flag.name === "ELISION" && flag.value) {
          findings.push(...phoneFindings(flag.value, mode, entry.line, "elision", null, melisma));
        }
        if (flag.name === "CONSONANT_PLACEMENT" && flag.value && !["onset", "offset", "split"].includes(flag.value)) {
          findings.push({
            severity: "warn",
            code: "FLAG",
            line: entry.line,
            message: "#CONSONANT_PLACEMENT must be onset, offset, or split.",
          });
        }
      }
      if (hasFlag(entry.flags, "STRESS_CONFLICT")) {
        findings.push({
          severity: "note",
          code: "STRESS",
          line: entry.line,
          message: "Stress conflict flagged. Speech stress stays in SYLLABLES — confirm the alignment did not quietly move ˈ.",
        });
      }
    }

    if (mode === "rap") {
      findings.push(...phoneFindings(phonemes, mode, entry.line, "phonemes", null, false));
      const rhyme = inspectRhyme(entry.cols[2] ?? "", entry.line);
      findings.push(...rhyme.findings);
      for (const tag of rhyme.tags) {
        const owners = rhymeOwners.get(tag) ?? [];
        owners.push(entry.word);
        rhymeOwners.set(tag, owners);
      }
      const elisionField = entry.cols[3] ?? "";
      const variants = elisionField.trim() && elisionField.trim() !== "-" && elisionField.trim() !== "?"
        ? elisionField.split(",").map((part) => part.trim()).filter(Boolean)
        : [];
      for (const variant of variants) {
        findings.push(...phoneFindings(variant, mode, entry.line, "elision", null, false));
      }
      const syllables = syllableCount(phonemes);
      if (syllables >= 2) {
        stats.multisyllabic += 1;
        if (variants.length > 0) stats.elidedMultisyllabic += 1;
      }
      for (const flag of entry.flags) {
        if (flag.name === "DIALECT") {
          const value = (flag.value ?? "").trim();
          if (!value || VAGUE_DIALECT.has(value.toLowerCase())) {
            findings.push({
              severity: "warn",
              code: "DIALECT",
              line: entry.line,
              message: "#DIALECT needs a real variety (GA, AAVE, RP), not a vague label.",
            });
          }
        }
        if (flag.name === "METER_FIT") {
          const n = Number(flag.value);
          if (!Number.isInteger(n) || n < 1) {
            findings.push({
              severity: "warn",
              code: "FLAG",
              line: entry.line,
              message: "#METER_FIT needs a positive integer.",
            });
          } else {
            const counts = [syllables, ...variants.map((variant) => syllableCount(variant))].filter((c) => c > 0);
            if (!counts.includes(n)) {
              findings.push({
                severity: "warn",
                code: "METER",
                line: entry.line,
                message: `#METER_FIT:${n} but none of the speech form or elisions is ${n} syllable${n === 1 ? "" : "s"}.`,
              });
            }
          }
        }
        if (flag.name === "HOMOPHONE_RHYME" && !flag.value?.trim()) {
          findings.push({
            severity: "warn",
            code: "FLAG",
            line: entry.line,
            message: "#HOMOPHONE_RHYME needs the other word.",
          });
        }
      }
    }
  }

  for (const [word, group] of byWord) {
    const posRows = group.filter((entry) => hasFlag(entry.flags, "POS"));
    const anyAlt = group.some((entry) => hasFlag(entry.flags, "ALT"));
    if (group.length >= 2 && posRows.length >= 2) {
      findings.push({
        severity: "note",
        code: "POS",
        line: group[0]?.line,
        message: `POS collision on “${word}”. Confirm the first row is the more frequent reading.`,
      });
    } else if (mode === "g2p" && posRows.length > 0 && !anyAlt) {
      findings.push({
        severity: "warn",
        code: "POS",
        line: posRows[0]?.line,
        message: "#POS is set but there is no #ALT and no second row. The other reading has to live somewhere.",
      });
    } else if (mode === "g2p" && group.length >= 2 && posRows.length === 0) {
      findings.push({
        severity: "warn",
        code: "DUP",
        line: group[0]?.line,
        message: `“${word}” appears ${group.length} times with no #POS. Duplicate, or an untagged homograph?`,
      });
    }
  }

  if (mode === "rap" && stats.multisyllabic > 0) {
    stats.elisionCoverage = stats.elidedMultisyllabic / stats.multisyllabic;
    if (stats.elisionCoverage < 0.8) {
      findings.push({
        severity: "warn",
        code: "ELISION",
        message: `Elision coverage is ${stats.elisionCoverage.toFixed(2)}. The gate is 0.8 of multisyllabic rows. The model is under-eliding.`,
      });
    }
  }

  for (const [tag, owners] of rhymeOwners) {
    const unique = [...new Set(owners)];
    if (unique.length < 2) continue;
    findings.push({
      severity: "note",
      code: "RHYME",
      message: `${tag} is shared by ${unique.join(", ")}. Confirm that collapse is intended — cot/caught must not merge in a dialect that keeps them apart.`,
    });
  }

  let probesInBatch = 0;
  for (const probe of GATE0) {
    const rows = entries.filter((entry) => entry.word.toLowerCase() === probe.word);
    if (rows.length === 0) {
      probes.push({ word: probe.word, expected: probe.ipa, actual: null, status: "absent", note: probe.note });
      continue;
    }
    probesInBatch += 1;
    const actual = (rows[0]?.cols[1] ?? "").trim();
    const status = actual === probe.ipa ? "match" : "diverge";
    probes.push({ word: probe.word, expected: probe.ipa, actual, status, note: probe.note });
    if (status === "diverge") {
      findings.push({
        severity: "note",
        code: "GATE0",
        line: rows[0]?.line,
        message: `Gate 0: “${probe.word}” is ${actual || "∅"} here; the reference is ${probe.ipa}. ${probe.note}`,
      });
    }
  }
  if (entries.length > 0 && probesInBatch === 0) {
    findings.push({
      severity: "note",
      code: "GATE0",
      message: "Gate 0 not exercised. Drop in the, of, and, to, a, in, is, you, that, it, he, was, for, on, are, as, with, his, they, I.",
    });
  }

  if (!stats.validationPresent) {
    findings.push({
      severity: "block",
      code: "VAL_MISSING",
      message: "No #VALIDATION block. The prompt requires one, and a batch without it is not acceptable.",
    });
  } else {
    stats.inventoryViolations = findings.filter((f) => f.code === "INV").length;
    for (const key of REQUIRED_KEYS[mode]) {
      if (!(key in declared)) {
        findings.push({
          severity: "warn",
          code: "VAL_KEY",
          message: `Validation block is missing #${key}.`,
        });
        continue;
      }
      if (PROSE_KEYS.has(key)) continue;
      const claimed = declared[key] ?? "";
      if (key === "INVENTORY_VIOLATIONS") {
        if (!numbersMatch(claimed, stats.inventoryViolations)) {
          findings.push({
            severity: "block",
            code: "VAL_DRIFT",
            message: `#INVENTORY_VIOLATIONS says ${claimed || "∅"}; the bench counts ${stats.inventoryViolations}. Do not accept the batch.`,
          });
        }
        continue;
      }
      if (key === "ELISION_COVERAGE") {
        if (stats.elisionCoverage != null && !coverageMatch(claimed, stats.elisionCoverage)) {
          findings.push({
            severity: "warn",
            code: "VAL_DRIFT",
            message: `#ELISION_COVERAGE says ${claimed}; the bench gets ${stats.elisionCoverage.toFixed(2)}.`,
          });
        }
        continue;
      }
      const actual = countForKey(key, stats);
      if (actual != null && !numbersMatch(claimed, actual)) {
        findings.push({
          severity: "warn",
          code: "VAL_DRIFT",
          message: `#${key} says ${claimed}; the bench counts ${actual}.`,
        });
      }
    }
  }

  if (!stats.validationPresent) {
    stats.inventoryViolations = findings.filter((f) => f.code === "INV").length;
  }

  return finish(mode, findings, stats, probes);
}

function countForKey(key: string, stats: ReviewStats): number | null {
  if (key === "OOV_COUNT") return stats.oov;
  if (key === "UNCERTAIN_COUNT") return stats.uncertain;
  if (key === "ALT_COUNT") return stats.alt;
  if (key === "ELISION_COUNT") return stats.elision;
  if (key === "MELISMA_RISK_COUNT") return stats.melisma;
  if (key === "DIALECT_COUNT") return stats.dialect;
  return null;
}

function modeLabelColumns(mode: Mode): string {
  if (mode === "g2p") return "Speak";
  if (mode === "singing") return "Sing";
  return "Rap";
}

function trimNum(value: number): string {
  return Number.isInteger(value) ? String(value) : value.toFixed(2).replace(/0$/, "").replace(/\.0$/, "");
}

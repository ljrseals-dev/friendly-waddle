export type Mode = "g2p" | "singing" | "rap";

export type Severity = "block" | "warn" | "note";

export type Finding = {
  severity: Severity;
  code: string;
  line?: number;
  message: string;
};

export type GateProbe = {
  word: string;
  expected: string;
  actual: string | null;
  status: "match" | "diverge" | "absent";
  note: string;
};

export type ReviewStats = {
  entries: number;
  inventoryViolations: number;
  oov: number;
  uncertain: number;
  alt: number;
  elision: number;
  melisma: number;
  dialect: number;
  multisyllabic: number;
  elidedMultisyllabic: number;
  elisionCoverage: number | null;
  validationPresent: boolean;
};

export type ReviewReport = {
  mode: Mode;
  findings: Finding[];
  stats: ReviewStats;
  probes: GateProbe[];
  blocks: number;
  warns: number;
};

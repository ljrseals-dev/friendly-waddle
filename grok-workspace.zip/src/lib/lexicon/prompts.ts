import { INVENTORY_BLOCK } from "./inventory.ts";
import type { Mode } from "./types.ts";

const BENCH = `BENCH CONTRACT (delivery):
- Raw UTF-8 text. No markdown fences. No prose before the first lexicon line.
- Tab characters between columns, never spaces.
- One lexicon entry per line, then a line exactly #VALIDATION, then the required count lines.
- Script g is ɡ (U+0261). The alveolar approximant is ɹ. Rhotic vowels are ɚ and ɝ.`;

const G2P_EXAMPLE = `WORKED EXAMPLE (format only — do not emit these unless they are in the input):
cat	kæt	-
strength	stɹɛŋθ	-
record	ˈɹɛ.kɚd	#POS:noun,#ALT:ɹɪ.ˈkɔɹd
Aureliax	?	#OOV`;

const SING_EXAMPLE = `WORKED EXAMPLE (format only — do not emit these unless they are in the input):
day	deɪ	1:d:0.5;2:e‿ɪ:2	-
father	ˈfɑ.ðɚ	1:ˈfɑː:2;2:ðɚ:1	-
Aureliax	?	?	#OOV`;

const RAP_EXAMPLE = `WORKED EXAMPLE (format only — do not emit these unless they are in the input):
every	ˈɛv.ə.ɹi	RC:i:∅	ˈɛv.ɹi	#METER_FIT:2
sing	ˈsɪŋ	RC:ɪ:ŋ,RC:ɪ:∅	-	-
police	pə.ˈlis	RC:i:s	ˈpoʊ.lis	#STRESS_SHIFT,#METER_FIT:2`;

export function buildSystemPrompt(mode: Mode, workedExample: boolean): string {
  if (mode === "g2p") return g2p(workedExample);
  if (mode === "singing") return singing(workedExample);
  return rap(workedExample);
}

export function buildFullPrompt(mode: Mode, words: string, workedExample: boolean): string {
  const list = words.trim() ? words.trim() : "(no word list yet)";
  return `${buildSystemPrompt(mode, workedExample)}

INPUT LIST:
${list}`;
}

function g2p(workedExample: boolean): string {
  return `You are a phonetics specialist generating a machine-readable pronunciation lexicon for a TTS frontend. You do not guess. When you do not know a pronunciation, you say so using the required flags.

${INVENTORY_BLOCK}

INPUT: a word list, one per line (multiword entries joined by _). Optional per-line POS hint in a second column, tab-separated.
TARGET: English — General American default, flag RP divergence.
PHONE SET: IPA, restricted to the declared inventory.

OUTPUT FORMAT — one entry per line, tab-separated:
WORD<TAB>PHONEMES<TAB>FLAGS

- PHONEMES: IPA, syllables separated by ., primary stress ˈ before the stressed syllable's onset, secondary ˌ where applicable.
- FLAGS: zero or more below, comma-separated, or - if none.

REQUIRED FLAGS:
- #OOV — word not in reliable knowledge. DO NOT emit phonemes; emit ? in the phoneme field. Mandatory for names, novel coinages, loanwords you cannot confidently transcribe.
- #UNCERTAIN — best-guess pronunciation, low confidence. Phonemes emitted; reviewer should check.
- #ALT:<phonemes> — competing attested pronunciation. Primary in phoneme field, alternative here.
- #POS:<tag> — POS-specific reading (record noun vs verb, read present vs past).
- #RP — GA and RP diverge; phoneme field is GA.
- #MULTIWORD — multiword expression; phonemes span the whole phrase with . between words too.

RULES:
1. Transcribe to the declared inventory only. If a pronunciation would require a phone not in the inventory, treat as #OOV rather than substituting.
2. Never guess a proper noun. #OOV is correct for an unfamiliar name even if it "looks" pronounceable.
3. Homographs with POS-dependent readings: more frequent reading primary, other under #ALT:, tag #POS: on both if POS hints supplied.
4. Multiword entries: single phoneme string, . between words, stress marked normally.
5. Do not emit IPA if the caller's engine expects ARPAbet — this prompt is IPA-only. If ARPAbet is needed, stop and say so.
6. No pronunciation for a word you would not bet on. #OOV is cheap; a wrong transcription is expensive downstream.
7. NEVER emit ː, ʰ, or ̩. These are outside the inventory and their presence indicates an error.

VALIDATION PASS — required, output after the lexicon:
#VALIDATION
#INVENTORY_VIOLATIONS: <count>
<list any phones not in the declared inventory, with offending lines>
#OOV_COUNT: <count>
#UNCERTAIN_COUNT: <count>
#ALT_COUNT: <count>
#POS_COLLISIONS: <list any word with multiple POS-tagged entries and confirm the primary is the more frequent reading>

If #INVENTORY_VIOLATIONS is nonzero, re-emit the offending lines with corrected phonemes or downgraded to #OOV.

${BENCH}
${workedExample ? `\n${G2P_EXAMPLE}\n` : ""}`;
}

function singing(workedExample: boolean): string {
  return `You are a phonetics specialist generating a SINGING pronunciation lexicon for a singing voice synthesizer. Input is a word list with optional melody hints (note durations in beats, comma-separated in a second tab-separated column). Output is IPA phonemes aligned to musical notes, with vowel elongation and consonant placement specified.

${INVENTORY_BLOCK}

The shared ban on ː is lifted only for the case below. ʰ and ̩ stay forbidden.

ADDITIONAL MARKS (this task only):
- ː vowel length — only on monophthongs, only when a note is sustained ≥ 2 beats. Not on diphthongs, except as documented melisma coloration under #MELISMA_RISK.
- ‿ tie — between phonemes sung across a note boundary, e.g. a‿ɪ.
- Bare a is legal only as a tie-split or melisma coloration of aɪ / aʊ. It is not otherwise a vowel in this inventory.

OUTPUT FORMAT — tab-separated:
WORD<TAB>SYLLABLES<TAB>NOTE_ALIGNMENT<TAB>FLAGS

- SYLLABLES: IPA with . between syllables, stress marked. Speech form. No ː in this column.
- NOTE_ALIGNMENT: one segment per note, format NOTE_INDEX:PHONEMES:DURATION_BEATS, segments separated by ; . Example: 1:kæ:1;2:t:0.5. Consonants belonging to the next note's onset are written at the start of that note's segment.
- FLAGS: as below, or - if none.

REQUIRED FLAGS:
- #OOV — unknown word, emit ? in the syllables field and ? in the alignment field.
- #UNCERTAIN — low confidence.
- #ELISION:<variant> — sung contraction exists (ev'ry, o'er, 'tis). Primary is full form, variant is sung form.
- #CONSONANT_PLACEMENT:<onset|offset|split> — for final clusters (strengths), where the cluster sits relative to the note boundary.
- #MELISMA_RISK — diphthong or vowel that, if sustained across notes, requires documented coloration (e.g. aɪ sustained → aːɪ or aɪə). Note chosen coloration in the segment.
- #STRESS_CONFLICT — supplied melody places a note on a syllable unstressed in speech. Emit speech stress in SYLLABLES and note melodic stress in the alignment field.

RULES:
1. Default vowel length unmarked. Add ː only when a note's duration ≥ 2 beats and the vowel is monophthongal.
2. Diphthongs sung across a note boundary: split with ‿, e.g. a‿ɪ.
3. Consonants assigned to the note of the syllable they begin, unless the caller's engine requires offset placement — if so, say so and re-emit.
4. Do not re-stress a word to fit the melody. Emit #STRESS_CONFLICT and let the caller decide.
5. #OOV remains mandatory; a wrong singing transcription is worse than a refusal because timing errors compound.
6. NEVER emit ʰ or ̩.
7. NOTE_ALIGNMENT is a candidate. The caller reconciles it with a deterministic aligner against the supplied durations. Still make the durations sum to the supplied melody.

VALIDATION PASS — required:
#VALIDATION
#INVENTORY_VIOLATIONS: <count>
<list any phones not in the declared inventory, with offending lines>
#OOV_COUNT: <count>
#UNCERTAIN_COUNT: <count>
#ELISION_COUNT: <count>
#MELISMA_RISK_COUNT: <count>
#NOTE_TOTAL_CHECK: <sum of durations per word; confirm matches supplied melody>

${BENCH}
${workedExample ? `\n${SING_EXAMPLE}\n` : ""}`;
}

function rap(workedExample: boolean): string {
  return `You are a phonetics specialist generating a RAP PERFORMANCE lexicon. Input is a word list with optional meter hints (target syllable count, or a stress skeleton like xXxX) in a second tab-separated column. Output is IPA with default speech stress, elision variants, and rhyme-class tags for assonance and consonance matching.

${INVENTORY_BLOCK}

ADDITIONAL MARK (this task only):
- ( ) elision mark — e.g. (ə) for optional schwa. Parentheses are allowed. ː, ʰ, and ̩ are not.

OUTPUT FORMAT — tab-separated:
WORD<TAB>PHONEMES<TAB>RHYME_CLASS<TAB>ELISIONS<TAB>FLAGS

- PHONEMES: IPA with . syllable boundaries and ˈ/ˌ for default speech stress.
- RHYME_CLASS: one or more tags RC:<vowel-set>:<coda-class>, comma-separated. Example: RC:ɪ:ŋ for "sing" (rhymes with ring, thing, king by assonance+coda), and RC:ɪ:∅ (open) by assonance alone. ∅ means an open coda.
- ELISIONS: comma-separated attested performance variants, e.g. ˈɛv.ɹi,ˈɛv.ə.ɹi for "every". Use - if the word is monosyllabic and has no variant.

REQUIRED FLAGS:
- #OOV — unknown word. Emit ? in the phoneme field. Do not invent a rhyme class for it; emit ? there too.
- #UNCERTAIN — low confidence.
- #METER_FIT:<n> — word can fill n syllables in performance (via elision or expansion), variants listed in ELISIONS.
- #STRESS_SHIFT — word commonly re-stressed in rap performance to fit meter (e.g. police → ˈpoʊ.lis). Emit speech stress as primary, note the shift in ELISIONS or the flag.
- #HOMOPHONE_RHYME:<word> — rhymes with a different word whose rhyme class differs from what spelling suggests; flag dialect dependence.
- #DIALECT:<GA|AAVE|RP|...> — pronunciation is dialect-dependent; emit GA default, note alternatives. Name a real variety. Never "non-standard".

RULES:
1. ELISIONS is not optional filler — it is the point. Every word with ≥ 2 syllables gets at least one elision variant where a performer would plausibly compress it.
2. Rhyme classes are PERFORMANCE classes, not dictionary rhymes. Two words with different codas but assonant nuclei and matching stress are rhyme-class compatible; the tag format captures both dimensions.
3. Stress marks in PHONEMES are SPEECH stress. Do not silently re-stress to fit a meter; use #STRESS_SHIFT.
4. Dialect sensitivity: AAVE and Southern US rap pronunciation diverge from GA in ways that matter for rhyme (-ing → -in, monophthongization, coda deletion). If you cannot attribute a variant to a dialect with confidence, omit rather than guess. Do not emit ː for monophthongization; this inventory forbids the length mark — describe the dialect in #DIALECT and give the inventory-legal vowel in ELISIONS.
5. #OOV remains mandatory.
6. NEVER emit ː, ʰ, or ̩.
7. The RC:<vowel-set>:<coda-class> scheme is a working invention (lexicon v1.0), not a published standard. Apply it consistently inside the batch.

VALIDATION PASS — required:
#VALIDATION
#INVENTORY_VIOLATIONS: <count>
<list any phones not in the declared inventory, with offending lines>
#OOV_COUNT: <count>
#UNCERTAIN_COUNT: <count>
#DIALECT_COUNT: <count>
#RHYME_CLASS_COLLISIONS: <words sharing a class — confirm intended>
#ELISION_COVERAGE: <fraction of multisyllabic entries with ≥ 1 elision variant>

${BENCH}
${workedExample ? `\n${RAP_EXAMPLE}\n` : ""}`;
}

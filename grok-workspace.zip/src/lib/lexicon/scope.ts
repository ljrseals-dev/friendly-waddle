export const scopeNotes: { title: string; body: string }[] = [
  {
    title: "DarkMind is retired",
    body: "DarkMind is an audio-in, audio-out vocoder. Modulator filterbank, envelope followers, unvoiced detector, seasonal morphing, pendulum carrier, carrier filterbank, band modulation, drive. No text path, no phoneme path, no lexicon interface. A pronunciation master for DarkMind is architecturally meaningless.",
  },
  {
    title: "Not a 100k-word factory",
    body: "At that scale the uncertain rate swamps review. Use a rule-based G2P — Phonetisaurus, or espeak-ng itself — as the base, and the model only for the OOV tail. This bench caps a batch at 40 lines.",
  },
  {
    title: "Singing alignment is a candidate",
    body: "The model produces plausible note assignments, not checked ones. Treat NOTE_ALIGNMENT as candidates and reconcile with a deterministic aligner that knows the supplied note count.",
  },
  {
    title: "Rhyme classes are versioned, not standard",
    body: "There is no canonical machine-readable rap rhyme scheme in the literature. RC:<vowel-set>:<coda-class> is a working invention. Change it on purpose, and change the version with it.",
  },
  {
    title: "Larynx and ARPAbet are deferred",
    body: "When an engine is named, swap the inventory block and add a substitution table. Larynx needs its own phone table. An ARPAbet companion keeps the same homograph and OOV logic and emits ARPAbet instead of IPA. This bench does not pretend to do either.",
  },
];

import type { Mode } from "./types.ts";

/** Script g, U+0261 — never ASCII g. */
export const SCRIPT_G = "\u0261";

export const CONSONANTS = [
  "p",
  "b",
  "t",
  "d",
  "k",
  SCRIPT_G,
  "f",
  "v",
  "θ",
  "ð",
  "s",
  "z",
  "ʃ",
  "ʒ",
  "h",
  "tʃ",
  "dʒ",
  "m",
  "n",
  "ŋ",
  "l",
  "ɹ",
  "j",
  "w",
] as const;

export const VOWELS = [
  "i",
  "ɪ",
  "e",
  "ɛ",
  "æ",
  "ɑ",
  "ɒ",
  "ɔ",
  "o",
  "ʊ",
  "u",
  "ʌ",
  "ə",
  "ɚ",
  "ɝ",
] as const;

export const DIPHTHONGS = ["eɪ", "aɪ", "ɔɪ", "aʊ", "oʊ"] as const;

export const STRESS = ["ˈ", "ˌ"] as const;

/** Monophthongs that may take singing length. Diphthongs may not. */
export const MONOPHTHONGS = new Set<string>(VOWELS);

export const INVENTORY_BLOCK = `DECLARED PHONE INVENTORY (IPA, espeak-ng-aligned) — DO NOT EMIT ANYTHING OUTSIDE THIS SET

CONSONANTS: p b t d k ${SCRIPT_G} f v θ ð s z ʃ ʒ h tʃ dʒ m n ŋ l ɹ j w
VOWELS:     i ɪ e ɛ æ ɑ ɒ ɔ o ʊ u ʌ ə ɚ ɝ
DIPHTHONGS: eɪ aɪ ɔɪ aʊ oʊ
STRESS:     ˈ ˌ
SYLLABLE:   .

Codepoint notes:
- ${SCRIPT_G} is U+0261 (script g), NOT ASCII g
- ɹ is the alveolar approximant, NOT r
- ɚ / ɝ are rhotic schwa / rhotic nurse; use these, not əɹ / ɜɹ

FORBIDDEN — presence indicates transcription error, not stylistic choice:
- ː (length mark)
- ʰ (aspiration diacritic)
- ̩ (syllabic diacritic)
- Any diacritic not listed above`;

export type Phone = {
  ipa: string;
  name: string;
};

export type PhoneGroup = {
  id: string;
  label: string;
  phones: Phone[];
};

export const PHONE_GROUPS: PhoneGroup[] = [
  {
    id: "stops",
    label: "Stops",
    phones: [
      { ipa: "p", name: "voiceless bilabial stop" },
      { ipa: "b", name: "voiced bilabial stop" },
      { ipa: "t", name: "voiceless alveolar stop" },
      { ipa: "d", name: "voiced alveolar stop" },
      { ipa: "k", name: "voiceless velar stop" },
      { ipa: SCRIPT_G, name: "voiced velar stop — script g, U+0261" },
    ],
  },
  {
    id: "fricatives",
    label: "Fricatives",
    phones: [
      { ipa: "f", name: "voiceless labiodental fricative" },
      { ipa: "v", name: "voiced labiodental fricative" },
      { ipa: "θ", name: "voiceless dental fricative" },
      { ipa: "ð", name: "voiced dental fricative" },
      { ipa: "s", name: "voiceless alveolar fricative" },
      { ipa: "z", name: "voiced alveolar fricative" },
      { ipa: "ʃ", name: "voiceless postalveolar fricative" },
      { ipa: "ʒ", name: "voiced postalveolar fricative" },
      { ipa: "h", name: "voiceless glottal fricative" },
    ],
  },
  {
    id: "affricates",
    label: "Affricates",
    phones: [
      { ipa: "tʃ", name: "voiceless postalveolar affricate" },
      { ipa: "dʒ", name: "voiced postalveolar affricate" },
    ],
  },
  {
    id: "sonorants",
    label: "Nasals, liquid, glides",
    phones: [
      { ipa: "m", name: "bilabial nasal" },
      { ipa: "n", name: "alveolar nasal" },
      { ipa: "ŋ", name: "velar nasal" },
      { ipa: "l", name: "alveolar lateral" },
      { ipa: "ɹ", name: "alveolar approximant — not ASCII r" },
      { ipa: "j", name: "palatal approximant" },
      { ipa: "w", name: "labial-velar approximant" },
    ],
  },
  {
    id: "vowels",
    label: "Vowels",
    phones: [
      { ipa: "i", name: "close front" },
      { ipa: "ɪ", name: "near-close front" },
      { ipa: "e", name: "close-mid front" },
      { ipa: "ɛ", name: "open-mid front" },
      { ipa: "æ", name: "near-open front" },
      { ipa: "ɑ", name: "open back unrounded" },
      { ipa: "ɒ", name: "open back rounded" },
      { ipa: "ɔ", name: "open-mid back rounded" },
      { ipa: "o", name: "close-mid back" },
      { ipa: "ʊ", name: "near-close back" },
      { ipa: "u", name: "close back" },
      { ipa: "ʌ", name: "open-mid back unrounded" },
      { ipa: "ə", name: "schwa" },
      { ipa: "ɚ", name: "rhotic schwa — not əɹ" },
      { ipa: "ɝ", name: "rhotic nurse — not ɜɹ" },
    ],
  },
  {
    id: "diphthongs",
    label: "Diphthongs",
    phones: [
      { ipa: "eɪ", name: "face" },
      { ipa: "aɪ", name: "price" },
      { ipa: "ɔɪ", name: "choice" },
      { ipa: "aʊ", name: "mouth" },
      { ipa: "oʊ", name: "goat" },
    ],
  },
  {
    id: "marks",
    label: "Stress and syllable",
    phones: [
      { ipa: "ˈ", name: "primary stress, before the stressed syllable onset" },
      { ipa: "ˌ", name: "secondary stress" },
      { ipa: ".", name: "syllable boundary" },
    ],
  },
];

export const SINGING_EXTRAS: Phone[] = [
  { ipa: "ː", name: "vowel length — monophthongs only, note ≥ 2 beats" },
  { ipa: "‿", name: "tie across a note boundary" },
  { ipa: "a", name: "split half of aɪ / aʊ only — not a general vowel" },
];

export const RAP_EXTRAS: Phone[] = [
  { ipa: "(", name: "elision mark, open" },
  { ipa: ")", name: "elision mark, close — (ə)" },
];

export const FORBIDDEN: Phone[] = [
  { ipa: "ː", name: "length — banned in Speak and Rap" },
  { ipa: "ʰ", name: "aspiration — banned in every mode" },
  { ipa: "̩", name: "syllabic diacritic — banned in every mode" },
  { ipa: "g", name: "ASCII g — use script ɡ" },
  { ipa: "r", name: "ASCII r — use ɹ" },
];

const KNOWN_REJECTS: Record<string, string> = {
  "ː": "length mark ː",
  "ʰ": "aspiration ʰ",
  "̩": "syllabic diacritic ̩",
  g: "ASCII g (U+0067) — the inventory requires script ɡ U+0261",
  r: "ASCII r — the inventory requires ɹ",
  R: "ASCII R — the inventory requires ɹ",
  "ɜ": "ɜ — use ɝ for rhotic nurse, not ɜ or ɜɹ",
  "ɐ": "ɐ is outside the inventory",
  "ɾ": "flap ɾ is outside the inventory",
  "ʔ": "glottal stop ʔ is outside the inventory",
  ":": "ASCII colon — not a length mark, and ː is forbidden outside singing",
  "(": "elision parentheses are a Rap-only mark",
  ")": "elision parentheses are a Rap-only mark",
  "‿": "tie ‿ is a Singing-only mark",
  a: "bare a is not a vowel in this inventory",
  " ": "space — separate syllables with . not spaces",
  "'": "ASCII apostrophe — stress is ˈ or ˌ",
  "ˈ": "primary stress",
  "ˌ": "secondary stress",
};

export function symbolsFor(mode: Mode): string[] {
  const symbols = new Set<string>([...CONSONANTS, ...VOWELS, ...DIPHTHONGS, ...STRESS, "."]);
  if (mode === "singing") {
    symbols.add("ː");
    symbols.add("‿");
    symbols.add("a");
  }
  if (mode === "rap") {
    symbols.add("(");
    symbols.add(")");
  }
  return [...symbols].sort((a, b) => b.length - a.length || a.localeCompare(b));
}

export type Token =
  | { kind: "phone"; value: string }
  | { kind: "bad"; value: string; detail: string };

export function tokenize(input: string, mode: Mode): Token[] {
  const symbols = symbolsFor(mode);
  const tokens: Token[] = [];
  let i = 0;
  while (i < input.length) {
    let matched = "";
    for (const symbol of symbols) {
      if (input.startsWith(symbol, i)) {
        matched = symbol;
        break;
      }
    }
    if (matched) {
      tokens.push({ kind: "phone", value: matched });
      i += matched.length;
      continue;
    }
    const cp = input.codePointAt(i) ?? 0;
    const ch = String.fromCodePoint(cp);
    const named = KNOWN_REJECTS[ch];
    const detail = named
      ? `${named} (${codepoint(ch)})`
      : `character ${codepoint(ch)} ‘${ch}’ is outside the declared inventory`;
    tokens.push({ kind: "bad", value: ch, detail });
    i += ch.length;
  }
  return tokens;
}

export function codepoint(text: string): string {
  return [...text]
    .map((ch) => {
      const cp = ch.codePointAt(0) ?? 0;
      return "U+" + cp.toString(16).toUpperCase().padStart(4, "0");
    })
    .join(" ");
}

export function modeLabel(mode: Mode): string {
  if (mode === "g2p") return "Speak";
  if (mode === "singing") return "Sing";
  return "Rap";
}

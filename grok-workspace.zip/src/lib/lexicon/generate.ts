import { createServerFn } from "@tanstack/react-start";
import { BATCH_CAP, listWords } from "./review.ts";
import { buildSystemPrompt } from "./prompts.ts";
import type { Mode } from "./types.ts";

export type GenerateResult = { ok: true; text: string } | { ok: false; error: string };

type GenerateInput = { mode: Mode; words: string; workedExample: boolean };

function readInput(input: unknown): GenerateInput | { error: string } {
  if (!input || typeof input !== "object") return { error: "Bad request." };
  const value = input as Record<string, unknown>;
  const mode = value.mode;
  if (mode !== "g2p" && mode !== "singing" && mode !== "rap") return { error: "Unknown lexicon mode." };
  if (typeof value.words !== "string") return { error: "Word list missing." };
  if (value.words.length > 8000) return { error: "Word list is too long." };
  const rows = listWords(value.words);
  if (rows.length === 0) return { error: "The word list is empty." };
  if (rows.length > BATCH_CAP) {
    return { error: `Batch cap is ${BATCH_CAP} lines. Past that, use a rule-based G2P and the model only on the OOV tail.` };
  }
  return { mode, words: value.words, workedExample: value.workedExample !== false };
}

function stripFences(text: string): string {
  const fenced = text.match(/```(?:[a-zA-Z]+)?\n([\s\S]*?)```/);
  return (fenced?.[1] ?? text).trim();
}

export const generateLexicon = createServerFn({ method: "POST" })
  .validator((input: unknown) => input)
  .handler(async ({ data }): Promise<GenerateResult> => {
    const parsed = readInput(data);
    if ("error" in parsed) return { ok: false, error: parsed.error };

    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false, error: "Transcription is unavailable in this environment. Paste a lexicon and review it anyway." };

    const system = buildSystemPrompt(parsed.mode, parsed.workedExample);
    const rows = listWords(parsed.words);
    const user = `INPUT LIST (${rows.length} lines). Output lexicon lines, then the validation block. No markdown fences. No preamble.\n\n${parsed.words.trim()}`;

    let response: Response;
    try {
      response = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        signal: AbortSignal.timeout(55_000),
        body: JSON.stringify({
          model: "grok-4.5",
          temperature: 0.2,
          max_tokens: 4096,
          messages: [
            { role: "system", content: system },
            { role: "user", content: user },
          ],
        }),
      });
    } catch {
      return { ok: false, error: "The transcription call did not complete. Try a shorter list." };
    }

    if (!response.ok) {
      return { ok: false, error: `Transcription failed (${response.status}). Nothing was changed.` };
    }

    const body = (await response.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const text = stripFences(body.choices?.[0]?.message?.content ?? "");
    if (!text) return { ok: false, error: "The model returned an empty lexicon." };
    return { ok: true, text };
  });

import assert from "node:assert/strict";
import { test } from "node:test";
import { CONSONANTS, SCRIPT_G, tokenize } from "./inventory.ts";
import { buildSystemPrompt } from "./prompts.ts";
import { reviewLexicon } from "./review.ts";
import { samples } from "./samples.ts";

test("script g is U+0261 and ASCII g is not a consonant", () => {
  assert.equal(SCRIPT_G, "\u0261");
  assert.equal(SCRIPT_G.codePointAt(0), 0x0261);
  assert.ok((CONSONANTS as readonly string[]).includes("\u0261"));
  assert.equal((CONSONANTS as readonly string[]).includes("g"), false);
});

test("prompts inline the inventory and do not leave the placeholder", () => {
  for (const mode of ["g2p", "singing", "rap"] as const) {
    const prompt = buildSystemPrompt(mode, true);
    assert.equal(prompt.includes("[SAME INVENTORY BLOCK]"), false);
    assert.ok(prompt.includes("\u0261"));
    assert.ok(prompt.includes("#OOV"));
    assert.ok(prompt.includes("#VALIDATION"));
  }
  assert.ok(buildSystemPrompt("g2p", false).includes("NEVER emit"));
  assert.equal(buildSystemPrompt("g2p", false).includes("WORKED EXAMPLE"), false);
});

test("clean speak sample passes the machine gate", () => {
  const sample = samples.find((item) => item.id === "g2p-clean");
  assert.ok(sample);
  const report = reviewLexicon(sample.mode, sample.output, sample.words);
  assert.equal(report.blocks, 0, JSON.stringify(report.findings, null, 2));
  assert.equal(report.warns, 0, JSON.stringify(report.findings, null, 2));
  assert.equal(report.stats.oov, 1);
  assert.equal(report.stats.inventoryViolations, 0);
  assert.equal(report.probes.filter((probe) => probe.status === "match").length, 5);
});

test("dirty speak sample blocks on forbidden phones and a lying validation block", () => {
  const sample = samples.find((item) => item.id === "g2p-dirty");
  assert.ok(sample);
  const report = reviewLexicon(sample.mode, sample.output, sample.words);
  assert.ok(report.stats.inventoryViolations >= 4);
  assert.ok(report.findings.some((finding) => finding.code === "VAL_DRIFT"));
  assert.ok(report.blocks > report.stats.inventoryViolations);
  const flat = report.findings.map((finding) => finding.message).join("\n");
  assert.match(flat, /U\+0067|ASCII g/);
  assert.match(flat, /aspiration/);
  assert.match(flat, /length mark/);
});

test("script g tokenizes and ASCII g does not", () => {
  assert.deepEqual(
    tokenize(`k${SCRIPT_G}oʊ`, "g2p").map((token) => token.kind),
    ["phone", "phone", "phone"],
  );
  assert.equal(tokenize("goʊ", "g2p").some((token) => token.kind === "bad"), true);
});

test("singing sample keeps length only on the long monophthong and matches the melody", () => {
  const sample = samples.find((item) => item.id === "singing");
  assert.ok(sample);
  const report = reviewLexicon(sample.mode, sample.output, sample.words);
  assert.equal(report.blocks, 0, JSON.stringify(report.findings, null, 2));
  assert.equal(report.warns, 0, JSON.stringify(report.findings, null, 2));
});

test("rap sample covers elisions and does not re-stress silently", () => {
  const sample = samples.find((item) => item.id === "rap");
  assert.ok(sample);
  const report = reviewLexicon(sample.mode, sample.output, sample.words);
  assert.equal(report.blocks, 0, JSON.stringify(report.findings, null, 2));
  assert.equal(report.warns, 0, JSON.stringify(report.findings, null, 2));
  assert.equal(report.stats.elisionCoverage, 1);
  assert.ok(report.findings.some((finding) => finding.code === "RHYME"));
});

test("OOV row with phonemes is refused", () => {
  const output = ["Zephyrielle\tkæt\t#OOV", "#VALIDATION", "#INVENTORY_VIOLATIONS: 0", "#OOV_COUNT: 1", "#UNCERTAIN_COUNT: 0", "#ALT_COUNT: 0", "#POS_COLLISIONS: -"].join("\n");
  const report = reviewLexicon("g2p", output, "Zephyrielle");
  assert.ok(report.findings.some((finding) => finding.code === "OOV_PHONES" && finding.severity === "block"));
});

test("missing validation block is a block", () => {
  const report = reviewLexicon("g2p", "cat\tkæt\t-", "cat");
  assert.ok(report.findings.some((finding) => finding.code === "VAL_MISSING"));
});

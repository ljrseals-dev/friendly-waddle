import type { Mode } from "./types.ts";

export type Sample = {
  id: string;
  mode: Mode;
  label: string;
  detail: string;
  words: string;
  output: string;
};

export const samples: Sample[] = [
  {
    id: "g2p-clean",
    mode: "g2p",
    label: "Speak — clean batch",
    detail: "Function words, a homograph, an RP flag, one refused name.",
    words: ["the", "of", "and", "to", "a", "record\tNN", "bath", "Zephyrielle"].join("\n"),
    output: [
      "the\tðə\t-",
      "of\təv\t-",
      "and\tænd\t-",
      "to\ttə\t-",
      "a\tə\t-",
      "record\tˈɹɛ.kɚd\t#POS:noun,#ALT:ɹɪ.ˈkɔɹd",
      "bath\tbæθ\t#RP",
      "Zephyrielle\t?\t#OOV",
      "#VALIDATION",
      "#INVENTORY_VIOLATIONS: 0",
      "#OOV_COUNT: 1",
      "#UNCERTAIN_COUNT: 0",
      "#ALT_COUNT: 1",
      "#POS_COLLISIONS: record has one POS-tagged row (noun); the verb sits in #ALT",
    ].join("\n"),
  },
  {
    id: "g2p-dirty",
    mode: "g2p",
    label: "Speak — inventory failures",
    detail: "Aspiration, ASCII g, length marks, and a validation block that lies.",
    words: ["cat", "go", "sea", "bird"].join("\n"),
    output: [
      "cat\tkʰæt\t-",
      "go\tgoʊ\t-",
      "sea\tsiː\t-",
      "bird\tbɜːd\t-",
      "#VALIDATION",
      "#INVENTORY_VIOLATIONS: 0",
      "#OOV_COUNT: 0",
      "#UNCERTAIN_COUNT: 0",
      "#ALT_COUNT: 0",
      "#POS_COLLISIONS: -",
    ].join("\n"),
  },
  {
    id: "singing",
    mode: "singing",
    label: "Sing — note alignment",
    detail: "Durations in the word list. Length only on a long monophthong.",
    words: ["day\t0.5,2", "father\t2,1"].join("\n"),
    output: [
      "day\tdeɪ\t1:d:0.5;2:e‿ɪ:2\t-",
      "father\tˈfɑ.ðɚ\t1:ˈfɑː:2;2:ðɚ:1\t-",
      "#VALIDATION",
      "#INVENTORY_VIOLATIONS: 0",
      "#OOV_COUNT: 0",
      "#UNCERTAIN_COUNT: 0",
      "#ELISION_COUNT: 0",
      "#MELISMA_RISK_COUNT: 0",
      "#NOTE_TOTAL_CHECK: day 2.5 = 0.5+2; father 3 = 2+1",
    ].join("\n"),
  },
  {
    id: "rap",
    mode: "rap",
    label: "Rap — elision and rhyme",
    detail: "Speech stress stays put. Performance variants live in the elision column.",
    words: ["every", "singing", "police", "king"].join("\n"),
    output: [
      "every\tˈɛv.ə.ɹi\tRC:i:∅\tˈɛv.ɹi\t#METER_FIT:2",
      "singing\tˈsɪŋ.ɪŋ\tRC:ɪ:ŋ,RC:ɪ:n\tˈsɪŋ.ɪn\t#DIALECT:AAVE,#METER_FIT:2",
      "police\tpə.ˈlis\tRC:i:s\tˈpoʊ.lis\t#STRESS_SHIFT,#METER_FIT:2",
      "king\tkɪŋ\tRC:ɪ:ŋ\t-\t-",
      "#VALIDATION",
      "#INVENTORY_VIOLATIONS: 0",
      "#OOV_COUNT: 0",
      "#UNCERTAIN_COUNT: 0",
      "#DIALECT_COUNT: 1",
      "#RHYME_CLASS_COLLISIONS: RC:ɪ:ŋ — singing, king (intended coda rhyme)",
      "#ELISION_COVERAGE: 1",
    ].join("\n"),
  },
];

export const defaultSample = samples[0];

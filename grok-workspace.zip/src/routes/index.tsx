import { createFileRoute } from "@tanstack/react-router";
import { Bench } from "@/components/lexicon/bench";

export const Route = createFileRoute("/")({ component: Bench });

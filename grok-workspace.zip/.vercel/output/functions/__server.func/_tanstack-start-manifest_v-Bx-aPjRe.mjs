//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bx-aPjRe.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-B2nxMPxi.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B2nxMPxi.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DcZ6Dc8f.js"]
	}
} });
//#endregion
export { tsrStartManifest };

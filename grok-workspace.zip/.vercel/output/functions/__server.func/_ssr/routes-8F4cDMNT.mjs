import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as buildFullPrompt, c as listWords, i as SINGING_EXTRAS, l as modeLabel, n as PHONE_GROUPS, r as RAP_EXTRAS, s as codepoint, t as FORBIDDEN, u as reviewLexicon } from "./prompts-B2AB_1QV.mjs";
import { n as Download, r as Copy, t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-8F4cDMNT.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SHARED = [
	{
		id: "oov-real",
		text: "Every #OOV is genuinely unknown. Names and novel forms should dominate. A common word here means the model is refusing too hard."
	},
	{
		id: "uncertain",
		text: "Read each #UNCERTAIN line against a dictionary. If they are more than 20% of a curated list, fix the prompt or the list before going on."
	},
	{
		id: "alt",
		text: "Every #ALT is attested, not invented. The primary is the more frequent reading."
	},
	{
		id: "pos",
		text: "Each POS-tagged homograph has its readings, and the primary matches ordinary frequency."
	},
	{
		id: "rp",
		text: "RP flags are real GA/RP splits. Spot-check bath, dance, trap, lot, thought, nurse, goose."
	}
];
var SINGING = [
	{
		id: "melisma",
		text: "Every #MELISMA_RISK writes a coloration in the segment. A bare flag is not done."
	},
	{
		id: "stress",
		text: "#STRESS_CONFLICT keeps speech stress in the syllable column. The melody does not get to move it silently."
	},
	{
		id: "aligner",
		text: "Note alignment is a candidate. Reconcile it with a deterministic aligner — note count against syllable count."
	}
];
var RAP = [
	{
		id: "rhyme",
		text: "Shared rhyme classes are intentional. Do not let cot and caught collapse in a dialect that keeps them apart."
	},
	{
		id: "dialect",
		text: "Dialect tags name a variety. “Non-standard” is not a variety."
	},
	{
		id: "taxonomy",
		text: "RC:<vowel>:<coda> is a working invention, lexicon v1.0. It is not a published standard. Version it if you change it."
	}
];
function checklistFor(mode) {
	if (mode === "singing") return [...SHARED, ...SINGING];
	if (mode === "rap") return [...SHARED, ...RAP];
	return SHARED;
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var generateLexicon = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("d39f36c3c16a9784b10ce67070668c4cf1dbdd5b7d8bc49c1500fbd6f689c4c1"));
var samples = [
	{
		id: "g2p-clean",
		mode: "g2p",
		label: "Speak — clean batch",
		detail: "Function words, a homograph, an RP flag, one refused name.",
		words: [
			"the",
			"of",
			"and",
			"to",
			"a",
			"record	NN",
			"bath",
			"Zephyrielle"
		].join("\n"),
		output: [
			"the	ðə	-",
			"of	əv	-",
			"and	ænd	-",
			"to	tə	-",
			"a	ə	-",
			"record	ˈɹɛ.kɚd	#POS:noun,#ALT:ɹɪ.ˈkɔɹd",
			"bath	bæθ	#RP",
			"Zephyrielle	?	#OOV",
			"#VALIDATION",
			"#INVENTORY_VIOLATIONS: 0",
			"#OOV_COUNT: 1",
			"#UNCERTAIN_COUNT: 0",
			"#ALT_COUNT: 1",
			"#POS_COLLISIONS: record has one POS-tagged row (noun); the verb sits in #ALT"
		].join("\n")
	},
	{
		id: "g2p-dirty",
		mode: "g2p",
		label: "Speak — inventory failures",
		detail: "Aspiration, ASCII g, length marks, and a validation block that lies.",
		words: [
			"cat",
			"go",
			"sea",
			"bird"
		].join("\n"),
		output: [
			"cat	kʰæt	-",
			"go	goʊ	-",
			"sea	siː	-",
			"bird	bɜːd	-",
			"#VALIDATION",
			"#INVENTORY_VIOLATIONS: 0",
			"#OOV_COUNT: 0",
			"#UNCERTAIN_COUNT: 0",
			"#ALT_COUNT: 0",
			"#POS_COLLISIONS: -"
		].join("\n")
	},
	{
		id: "singing",
		mode: "singing",
		label: "Sing — note alignment",
		detail: "Durations in the word list. Length only on a long monophthong.",
		words: ["day	0.5,2", "father	2,1"].join("\n"),
		output: [
			"day	deɪ	1:d:0.5;2:e‿ɪ:2	-",
			"father	ˈfɑ.ðɚ	1:ˈfɑː:2;2:ðɚ:1	-",
			"#VALIDATION",
			"#INVENTORY_VIOLATIONS: 0",
			"#OOV_COUNT: 0",
			"#UNCERTAIN_COUNT: 0",
			"#ELISION_COUNT: 0",
			"#MELISMA_RISK_COUNT: 0",
			"#NOTE_TOTAL_CHECK: day 2.5 = 0.5+2; father 3 = 2+1"
		].join("\n")
	},
	{
		id: "rap",
		mode: "rap",
		label: "Rap — elision and rhyme",
		detail: "Speech stress stays put. Performance variants live in the elision column.",
		words: [
			"every",
			"singing",
			"police",
			"king"
		].join("\n"),
		output: [
			"every	ˈɛv.ə.ɹi	RC:i:∅	ˈɛv.ɹi	#METER_FIT:2",
			"singing	ˈsɪŋ.ɪŋ	RC:ɪ:ŋ,RC:ɪ:n	ˈsɪŋ.ɪn	#DIALECT:AAVE,#METER_FIT:2",
			"police	pə.ˈlis	RC:i:s	ˈpoʊ.lis	#STRESS_SHIFT,#METER_FIT:2",
			"king	kɪŋ	RC:ɪ:ŋ	-	-",
			"#VALIDATION",
			"#INVENTORY_VIOLATIONS: 0",
			"#OOV_COUNT: 0",
			"#UNCERTAIN_COUNT: 0",
			"#DIALECT_COUNT: 1",
			"#RHYME_CLASS_COLLISIONS: RC:ɪ:ŋ — singing, king (intended coda rhyme)",
			"#ELISION_COVERAGE: 1"
		].join("\n")
	}
];
var defaultSample = samples[0];
var scopeNotes = [
	{
		title: "DarkMind is retired",
		body: "DarkMind is an audio-in, audio-out vocoder. Modulator filterbank, envelope followers, unvoiced detector, seasonal morphing, pendulum carrier, carrier filterbank, band modulation, drive. No text path, no phoneme path, no lexicon interface. A pronunciation master for DarkMind is architecturally meaningless."
	},
	{
		title: "Not a 100k-word factory",
		body: "At that scale the uncertain rate swamps review. Use a rule-based G2P — Phonetisaurus, or espeak-ng itself — as the base, and the model only for the OOV tail. This bench caps a batch at 40 lines."
	},
	{
		title: "Singing alignment is a candidate",
		body: "The model produces plausible note assignments, not checked ones. Treat NOTE_ALIGNMENT as candidates and reconcile with a deterministic aligner that knows the supplied note count."
	},
	{
		title: "Rhyme classes are versioned, not standard",
		body: "There is no canonical machine-readable rap rhyme scheme in the literature. RC:<vowel-set>:<coda-class> is a working invention. Change it on purpose, and change the version with it."
	},
	{
		title: "Larynx and ARPAbet are deferred",
		body: "When an engine is named, swap the inventory block and add a substitution table. Larynx needs its own phone table. An ARPAbet companion keeps the same homograph and OOV logic and emits ARPAbet instead of IPA. This bench does not pretend to do either."
	}
];
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var STORAGE = "gate-zero-v1";
var CHECKS = "gate-zero-checks-v1";
var MODES = [
	{
		id: "g2p",
		title: "Speak",
		detail: "G2P",
		line: "Citation lexicon for a TTS frontend. General American. IPA only."
	},
	{
		id: "singing",
		title: "Sing",
		detail: "Notes",
		line: "Syllables aligned to beats. Length only on a long monophthong. Alignment is a candidate."
	},
	{
		id: "rap",
		title: "Rap",
		detail: "Meter",
		line: "Speech stress stays put. Elisions and rhyme class RC:vowel:coda do the performance work."
	}
];
var PLACEHOLDER = {
	g2p: "the\nrecord	NN\nbath\nZephyrielle",
	singing: "day	0.5,2\nfather	2,1",
	rap: "every\nsinging\npolice\nking"
};
function isMode(value) {
	return value === "g2p" || value === "singing" || value === "rap";
}
function Bench() {
	const [mode, setMode] = (0, import_react.useState)(defaultSample.mode);
	const [words, setWords] = (0, import_react.useState)(defaultSample.words);
	const [output, setOutput] = (0, import_react.useState)(defaultSample.output);
	const [worked, setWorked] = (0, import_react.useState)(true);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [checks, setChecks] = (0, import_react.useState)({});
	const [showAbsent, setShowAbsent] = (0, import_react.useState)(false);
	const [inspector, setInspector] = (0, import_react.useState)(PHONE_GROUPS[0]?.phones[0] ?? {
		ipa: "ɡ",
		name: "script g"
	});
	const outputRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem(STORAGE);
			if (raw) {
				const session = JSON.parse(raw);
				if (isMode(session.mode) && typeof session.words === "string" && typeof session.output === "string") {
					setMode(session.mode);
					setWords(session.words);
					setOutput(session.output);
					setWorked(session.worked !== false);
				}
			}
			const storedChecks = localStorage.getItem(CHECKS);
			if (storedChecks) {
				const parsed = JSON.parse(storedChecks);
				if (parsed && typeof parsed === "object") setChecks(parsed);
			}
		} catch {}
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		localStorage.setItem(STORAGE, JSON.stringify({
			mode,
			words,
			output,
			worked
		}));
	}, [
		ready,
		mode,
		words,
		output,
		worked
	]);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		localStorage.setItem(CHECKS, JSON.stringify(checks));
	}, [ready, checks]);
	const report = (0, import_react.useMemo)(() => reviewLexicon(mode, output, words), [
		mode,
		output,
		words
	]);
	const prompt = (0, import_react.useMemo)(() => buildFullPrompt(mode, words, worked), [
		mode,
		words,
		worked
	]);
	const count = listWords(words).length;
	const overCap = count > 40;
	const modeCopy = MODES.find((item) => item.id === mode) ?? MODES[0];
	const checksForMode = checklistFor(mode);
	const presentProbes = report.probes.filter((probe) => probe.status !== "absent");
	const visibleProbes = showAbsent ? report.probes : presentProbes;
	const verdict = report.stats.entries === 0 ? "Nothing in the gate" : report.blocks > 0 ? "Do not accept" : "Machine gate clear";
	function applySample(id) {
		const sample = samples.find((item) => item.id === id);
		if (!sample) return;
		setMode(sample.mode);
		setWords(sample.words);
		setOutput(sample.output);
		setError(null);
		setShowAbsent(false);
	}
	async function copyPrompt() {
		try {
			await navigator.clipboard.writeText(prompt);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1600);
		} catch {
			setError("Could not copy the prompt.");
		}
	}
	function downloadLexicon() {
		const blob = new Blob([output], { type: "text/tab-separated-values;charset=utf-8" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = `gate-zero-${mode}.tsv`;
		link.click();
		URL.revokeObjectURL(url);
	}
	async function transcribe() {
		if (busy || overCap || count === 0) return;
		setBusy(true);
		setError(null);
		try {
			const result = await generateLexicon({ data: {
				mode,
				words,
				workedExample: worked
			} });
			if (!result.ok) {
				setError(result.error);
				return;
			}
			setOutput(result.text);
		} catch {
			setError("Transcription did not complete.");
		} finally {
			setBusy(false);
		}
	}
	function insertPhone(phone) {
		setInspector(phone);
		const el = outputRef.current;
		if (!el) {
			setOutput((prev) => prev + phone.ipa);
			return;
		}
		const start = el.selectionStart ?? output.length;
		const end = el.selectionEnd ?? start;
		const next = output.slice(0, start) + phone.ipa + output.slice(end);
		setOutput(next);
		requestAnimationFrame(() => {
			el.focus();
			const caret = start + phone.ipa.length;
			el.setSelectionRange(caret, caret);
		});
	}
	const banned = FORBIDDEN.filter((phone) => !(mode === "singing" && phone.ipa === "ː"));
	const extras = mode === "singing" ? SINGING_EXTRAS : mode === "rap" ? RAP_EXTRAS : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-ink text-ivory",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "border-b border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl flex-col gap-5 px-4 py-5 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-wide text-brass uppercase",
							children: "Lexicon 1.0 · IPA"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-1 font-display text-4xl leading-none text-ivory",
							children: ["Gate ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "italic text-brass",
								children: "Zero"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-md text-sm text-mute",
							children: "Three pronunciation lexicons. One declared phone set. A line is not trusted until the gate says so."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					role: "tablist",
					"aria-label": "Lexicon mode",
					className: "grid grid-cols-3 gap-2 sm:w-80",
					children: MODES.map((item) => {
						const on = item.id === mode;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							role: "tab",
							"aria-selected": on,
							onClick: () => setMode(item.id),
							className: cn("min-h-11 rounded-xl px-3 py-2 text-left transition-opacity duration-200", on ? "bg-brass text-ink" : "bg-paper text-ivory ring-desk"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-display text-lg leading-none",
								children: item.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("mt-1 block text-xs", on ? "opacity-70" : "text-mute"),
								children: item.detail
							})]
						}, item.id);
					})
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto grid max-w-6xl gap-6 px-4 py-6 lg:grid-cols-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-6 lg:col-span-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-mute",
						children: modeCopy.line
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-mute",
						children: [
							"Engine ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-ivory",
								children: "IPA, espeak-ng aligned"
							}),
							". Larynx and ARPAbet stay deferred until a substitution table is named."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-2xl bg-paper p-4 ring-desk sm:p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-end justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
									className: "font-display text-2xl",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mr-2 text-brass",
										children: "01"
									}), "List"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: cn("text-sm tabular-nums", overCap ? "text-brass" : "text-mute"),
									children: [
										count,
										" / ",
										40
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-mute",
								children: "One word a line. An optional second column is a tab: part of speech, beat durations, or a meter hint."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mt-4 block text-sm text-mute",
								htmlFor: "word-list",
								children: ["Word list", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									id: "word-list",
									value: words,
									onChange: (event) => setWords(event.target.value),
									placeholder: PLACEHOLDER[mode],
									spellCheck: false,
									className: "mt-2 min-h-32 w-full resize-y px-3 py-3 text-sm leading-relaxed text-ivory placeholder:text-mute"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "min-w-40 flex-1 text-sm text-mute",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "sr-only",
										children: "Load a sample batch"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										className: "h-11 w-full px-3 text-sm text-ivory",
										defaultValue: "",
										onChange: (event) => {
											applySample(event.target.value);
											event.currentTarget.value = "";
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											children: "Load a sample…"
										}), samples.map((sample) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: sample.id,
											children: sample.label
										}, sample.id))]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										setWords("");
										setOutput("");
										setError(null);
									},
									className: "h-11 rounded-lg bg-raised px-4 text-sm text-ivory ring-desk",
									children: "Clear"
								})]
							}),
							overCap ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 text-sm text-brass",
								children: [
									"Past ",
									40,
									" lines the uncertain rate swamps review. Use espeak-ng or Phonetisaurus as the base, and the model only on the OOV tail."
								]
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-2xl bg-paper p-4 ring-desk sm:p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-end justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
									className: "font-display text-2xl",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mr-2 text-brass",
										children: "02"
									}), "Transcript"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-mute tabular-nums",
									children: [report.stats.entries, " rows"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-mute",
								children: "Paste a model’s lexicon, or transcribe this list. Output is tab-separated, then a #VALIDATION block."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex flex-wrap gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: transcribe,
										disabled: busy || overCap || count === 0,
										className: "h-11 rounded-lg bg-brass px-4 text-sm font-medium text-ink disabled:opacity-40",
										children: busy ? "Transcribing…" : "Transcribe batch"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: copyPrompt,
										className: "inline-flex h-11 items-center gap-2 rounded-lg bg-raised px-4 text-sm text-ivory ring-desk",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
											className: "size-4",
											"aria-hidden": "true"
										}), copied ? "Copied" : "Copy prompt"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: downloadLexicon,
										disabled: !output.trim(),
										className: "inline-flex h-11 items-center gap-2 rounded-lg bg-raised px-4 text-sm text-ivory ring-desk disabled:opacity-40",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
											className: "size-4",
											"aria-hidden": "true"
										}), "Download"]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mt-4 flex min-h-11 items-start gap-3 text-sm text-ivory",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: worked,
									onChange: (event) => setWorked(event.target.checked),
									className: "mt-1 size-4 accent-brass"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Include a worked example in the prompt. Use this when a model keeps emitting ː, ʰ, or ̩." })]
							}),
							error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								role: "alert",
								className: "mt-3 flex items-start gap-2 text-sm text-brass",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
									className: "mt-0.5 size-4 shrink-0",
									"aria-hidden": "true"
								}), error]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mt-4 block text-sm text-mute",
								htmlFor: "lexicon-output",
								children: ["Lexicon", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									id: "lexicon-output",
									ref: outputRef,
									value: output,
									onChange: (event) => setOutput(event.target.value),
									spellCheck: false,
									className: "mt-2 min-h-48 w-full resize-y px-3 py-3 text-sm leading-relaxed text-ivory"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
								className: "mt-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
									className: "flex min-h-11 items-center text-sm text-ivory",
									children: "Assembled prompt"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
									className: "mt-2 max-h-80 overflow-auto rounded-lg bg-ink p-3 text-sm leading-relaxed whitespace-pre-wrap text-mute",
									children: prompt
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-2xl bg-paper p-4 ring-desk sm:p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "font-display text-2xl",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mr-2 text-brass",
									children: "03"
								}), "Inventory"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-sm text-ivory",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium",
										children: inspector.ipa
									}),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-mute",
										children: [
											codepoint(inspector.ipa),
											" — ",
											inspector.name
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-mute",
								children: "Click a phone to drop the real character into the transcript. ASCII g and r are not in the set."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex flex-col gap-4",
								children: [
									PHONE_GROUPS.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneRow, {
										label: group.label,
										phones: group.phones,
										active: inspector.ipa,
										onPick: insertPhone
									}, group.id)),
									extras.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneRow, {
										label: mode === "singing" ? "Singing marks" : "Rap marks",
										phones: extras,
										active: inspector.ipa,
										onPick: insertPhone
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneRow, {
										label: "Banned",
										phones: banned,
										active: inspector.ipa,
										onPick: (phone) => setInspector(phone)
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-2xl bg-paper p-4 ring-desk sm:p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl",
							children: "Out of scope"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 flex flex-col gap-4",
							children: scopeNotes.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-medium text-ivory",
								children: note.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-mute",
								children: note.body
							})] }, note.title))
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "lg:col-span-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-4 lg:sticky lg:top-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-2xl bg-paper p-4 ring-desk sm:p-5",
							"aria-live": "polite",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs tracking-wide text-brass uppercase",
									children: [modeLabel(mode), " review"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-1 font-display text-3xl",
									children: verdict
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-sm text-mute",
									children: [
										report.blocks,
										" blocking · ",
										report.warns,
										" to check · ",
										report.findings.length - report.blocks - report.warns,
										" notes. The machine gate is not the whole review."
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
									className: "mt-4 grid grid-cols-2 gap-px overflow-hidden rounded-xl bg-line sm:grid-cols-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
											label: "Blocks",
											value: String(report.blocks),
											hot: report.blocks > 0
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
											label: "Outside set",
											value: String(report.stats.inventoryViolations),
											hot: report.stats.inventoryViolations > 0
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
											label: "OOV",
											value: String(report.stats.oov)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
											label: mode === "rap" ? "Elision" : mode === "singing" ? "Melisma" : "Alt",
											value: mode === "rap" ? report.stats.elisionCoverage == null ? "—" : report.stats.elisionCoverage.toFixed(2) : mode === "singing" ? String(report.stats.melisma) : String(report.stats.alt)
										})
									]
								}),
								mode === "rap" && report.stats.multisyllabic > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 text-sm text-mute",
									children: [
										"Elision coverage ",
										report.stats.elidedMultisyllabic,
										"/",
										report.stats.multisyllabic,
										" multisyllabic rows. Gate is 0.80."
									]
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-2xl bg-paper ring-desk",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "px-4 pt-4 sm:px-5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-xl",
									children: "Findings"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 max-h-96 overflow-auto",
								children: report.findings.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "px-4 py-4 text-sm text-mute sm:px-5",
									children: "No findings."
								}) : report.findings.map((finding, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "border-t border-line px-4 py-3 sm:px-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-baseline justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: cn("text-xs tracking-wide uppercase", finding.severity === "block" ? "text-brass" : "text-mute"),
											children: [finding.severity === "block" ? "Block" : finding.severity === "warn" ? "Check" : "Note", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "ml-2 normal-case tracking-normal",
												children: finding.code
											})]
										}), finding.line ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-xs text-mute tabular-nums",
											children: ["Line ", finding.line]
										}) : null]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-ivory",
										children: finding.message
									})]
								}, `${finding.code}-${finding.line ?? "x"}-${index}`))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-2xl bg-paper p-4 ring-desk sm:p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-xl",
										children: "Gate 0"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm text-mute tabular-nums",
										children: [
											presentProbes.filter((probe) => probe.status === "match").length,
											"/",
											presentProbes.length || 0,
											" in batch"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-mute",
									children: "Twenty frequent words, inventory-normalized General American. This is a convention reference, not a live espeak-ng process. A mismatch is a diff to judge, not an automatic reject."
								}),
								presentProbes.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm text-ivory",
									children: "None of the probes are in this batch."
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-3 flex flex-col gap-2",
									children: visibleProbes.map((probe) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "grid grid-cols-3 items-baseline gap-2 text-sm",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-ivory",
												children: probe.word
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: cn(probe.status === "diverge" ? "text-brass" : "text-ivory"),
												children: probe.status === "absent" ? "—" : probe.actual
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-mute",
												children: [probe.expected, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "ml-2 text-xs uppercase",
													children: probe.status === "match" ? "match" : probe.status === "diverge" ? "differs" : "absent"
												})]
											})
										]
									}, probe.word))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setShowAbsent((value) => !value),
									className: "mt-3 min-h-11 text-sm text-brass",
									children: showAbsent ? "Hide absent probes" : "Show absent probes"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-2xl bg-paper p-4 ring-desk sm:p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-xl",
									children: "Still on you"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-mute",
									children: "The bench cannot see a dictionary. These stay human."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-2",
									children: checksForMode.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex min-h-11 items-start gap-3 py-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											checked: Boolean(checks[item.id]),
											onChange: (event) => setChecks((prev) => ({
												...prev,
												[item.id]: event.target.checked
											})),
											className: "mt-1 size-4 shrink-0 accent-brass"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm text-ivory",
											children: item.text
										})]
									}) }, item.id))
								})
							]
						})
					]
				})
			})]
		})]
	});
}
function Stat({ label, value, hot = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-paper px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs text-mute",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: cn("mt-1 font-display text-2xl tabular-nums", hot ? "text-brass" : "text-ivory"),
			children: value
		})]
	});
}
function PhoneRow({ label, phones, active, onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
		className: "text-sm text-mute",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-2 flex flex-wrap gap-2",
		children: phones.map((phone) => {
			const on = phone.ipa === active;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onPick(phone),
				"aria-pressed": on,
				className: cn("flex h-11 min-w-11 items-center justify-center rounded-lg px-2 text-lg", on ? "bg-brass text-ink" : "bg-ink text-ivory ring-desk"),
				children: phone.ipa
			}, `${label}-${phone.ipa}`);
		})
	})] });
}
var SplitComponent = Bench;
//#endregion
export { SplitComponent as component };

//#region node_modules/.nitro/vite/services/ssr/assets/prompts-B2AB_1QV.js
/**
* Gate 0 probes. Inventory-normalized General American citation/function-word
* forms — a convention reference, not a live espeak-ng process. Divergences
* are diffs to adjudicate, not automatic rejects.
*/
var GATE0 = [
	{
		word: "the",
		ipa: "ðə",
		note: "Unstressed function word. ði before a vowel is the alt."
	},
	{
		word: "of",
		ipa: "əv",
		note: "Unstressed. ʌv is the strong form."
	},
	{
		word: "and",
		ipa: "ænd",
		note: "Full form. ən is a reduction, and syllabic n is forbidden."
	},
	{
		word: "to",
		ipa: "tə",
		note: "Unstressed. tu before a vowel is the alt."
	},
	{
		word: "a",
		ipa: "ə",
		note: "Unstressed article. eɪ is the letter name, not the word."
	},
	{
		word: "in",
		ipa: "ɪn",
		note: "Citation form."
	},
	{
		word: "is",
		ipa: "ɪz",
		note: "Citation form."
	},
	{
		word: "you",
		ipa: "ju",
		note: "Citation form."
	},
	{
		word: "that",
		ipa: "ðæt",
		note: "Strong form of the demonstrative and complementizer."
	},
	{
		word: "it",
		ipa: "ɪt",
		note: "Citation form."
	},
	{
		word: "he",
		ipa: "hi",
		note: "Citation form. hi is not i."
	},
	{
		word: "was",
		ipa: "wʌz",
		note: "Strong form. wəz is the reduction."
	},
	{
		word: "for",
		ipa: "fɚ",
		note: "Rhotic schwa. Not fɔɹ and not fə."
	},
	{
		word: "on",
		ipa: "ɑn",
		note: "GA lot vowel. ɔn is the non-merged alt."
	},
	{
		word: "are",
		ipa: "ɑɹ",
		note: "Strong form. Unstressed ɚ is the reduction."
	},
	{
		word: "as",
		ipa: "æz",
		note: "Strong form. əz is the reduction."
	},
	{
		word: "with",
		ipa: "wɪð",
		note: "Voiced ð is the GA default here. wɪθ is attested."
	},
	{
		word: "his",
		ipa: "hɪz",
		note: "Citation form."
	},
	{
		word: "they",
		ipa: "ðeɪ",
		note: "Citation form."
	},
	{
		word: "i",
		ipa: "aɪ",
		note: "The pronoun. Orthography I or i."
	}
];
var CONSONANTS = [
	"p",
	"b",
	"t",
	"d",
	"k",
	"ɡ",
	"f",
	"v",
	"θ",
	"ð",
	"s",
	"z",
	"ʃ",
	"ʒ",
	"h",
	"tʃ",
	"dʒ",
	"m",
	"n",
	"ŋ",
	"l",
	"ɹ",
	"j",
	"w"
];
var VOWELS = [
	"i",
	"ɪ",
	"e",
	"ɛ",
	"æ",
	"ɑ",
	"ɒ",
	"ɔ",
	"o",
	"ʊ",
	"u",
	"ʌ",
	"ə",
	"ɚ",
	"ɝ"
];
var DIPHTHONGS = [
	"eɪ",
	"aɪ",
	"ɔɪ",
	"aʊ",
	"oʊ"
];
var STRESS = ["ˈ", "ˌ"];
/** Monophthongs that may take singing length. Diphthongs may not. */
var MONOPHTHONGS = new Set(VOWELS);
var INVENTORY_BLOCK = `DECLARED PHONE INVENTORY (IPA, espeak-ng-aligned) — DO NOT EMIT ANYTHING OUTSIDE THIS SET

CONSONANTS: p b t d k ɡ f v θ ð s z ʃ ʒ h tʃ dʒ m n ŋ l ɹ j w
VOWELS:     i ɪ e ɛ æ ɑ ɒ ɔ o ʊ u ʌ ə ɚ ɝ
DIPHTHONGS: eɪ aɪ ɔɪ aʊ oʊ
STRESS:     ˈ ˌ
SYLLABLE:   .

Codepoint notes:
- ɡ is U+0261 (script g), NOT ASCII g
- ɹ is the alveolar approximant, NOT r
- ɚ / ɝ are rhotic schwa / rhotic nurse; use these, not əɹ / ɜɹ

FORBIDDEN — presence indicates transcription error, not stylistic choice:
- ː (length mark)
- ʰ (aspiration diacritic)
- ̩ (syllabic diacritic)
- Any diacritic not listed above`;
var PHONE_GROUPS = [
	{
		id: "stops",
		label: "Stops",
		phones: [
			{
				ipa: "p",
				name: "voiceless bilabial stop"
			},
			{
				ipa: "b",
				name: "voiced bilabial stop"
			},
			{
				ipa: "t",
				name: "voiceless alveolar stop"
			},
			{
				ipa: "d",
				name: "voiced alveolar stop"
			},
			{
				ipa: "k",
				name: "voiceless velar stop"
			},
			{
				ipa: "ɡ",
				name: "voiced velar stop — script g, U+0261"
			}
		]
	},
	{
		id: "fricatives",
		label: "Fricatives",
		phones: [
			{
				ipa: "f",
				name: "voiceless labiodental fricative"
			},
			{
				ipa: "v",
				name: "voiced labiodental fricative"
			},
			{
				ipa: "θ",
				name: "voiceless dental fricative"
			},
			{
				ipa: "ð",
				name: "voiced dental fricative"
			},
			{
				ipa: "s",
				name: "voiceless alveolar fricative"
			},
			{
				ipa: "z",
				name: "voiced alveolar fricative"
			},
			{
				ipa: "ʃ",
				name: "voiceless postalveolar fricative"
			},
			{
				ipa: "ʒ",
				name: "voiced postalveolar fricative"
			},
			{
				ipa: "h",
				name: "voiceless glottal fricative"
			}
		]
	},
	{
		id: "affricates",
		label: "Affricates",
		phones: [{
			ipa: "tʃ",
			name: "voiceless postalveolar affricate"
		}, {
			ipa: "dʒ",
			name: "voiced postalveolar affricate"
		}]
	},
	{
		id: "sonorants",
		label: "Nasals, liquid, glides",
		phones: [
			{
				ipa: "m",
				name: "bilabial nasal"
			},
			{
				ipa: "n",
				name: "alveolar nasal"
			},
			{
				ipa: "ŋ",
				name: "velar nasal"
			},
			{
				ipa: "l",
				name: "alveolar lateral"
			},
			{
				ipa: "ɹ",
				name: "alveolar approximant — not ASCII r"
			},
			{
				ipa: "j",
				name: "palatal approximant"
			},
			{
				ipa: "w",
				name: "labial-velar approximant"
			}
		]
	},
	{
		id: "vowels",
		label: "Vowels",
		phones: [
			{
				ipa: "i",
				name: "close front"
			},
			{
				ipa: "ɪ",
				name: "near-close front"
			},
			{
				ipa: "e",
				name: "close-mid front"
			},
			{
				ipa: "ɛ",
				name: "open-mid front"
			},
			{
				ipa: "æ",
				name: "near-open front"
			},
			{
				ipa: "ɑ",
				name: "open back unrounded"
			},
			{
				ipa: "ɒ",
				name: "open back rounded"
			},
			{
				ipa: "ɔ",
				name: "open-mid back rounded"
			},
			{
				ipa: "o",
				name: "close-mid back"
			},
			{
				ipa: "ʊ",
				name: "near-close back"
			},
			{
				ipa: "u",
				name: "close back"
			},
			{
				ipa: "ʌ",
				name: "open-mid back unrounded"
			},
			{
				ipa: "ə",
				name: "schwa"
			},
			{
				ipa: "ɚ",
				name: "rhotic schwa — not əɹ"
			},
			{
				ipa: "ɝ",
				name: "rhotic nurse — not ɜɹ"
			}
		]
	},
	{
		id: "diphthongs",
		label: "Diphthongs",
		phones: [
			{
				ipa: "eɪ",
				name: "face"
			},
			{
				ipa: "aɪ",
				name: "price"
			},
			{
				ipa: "ɔɪ",
				name: "choice"
			},
			{
				ipa: "aʊ",
				name: "mouth"
			},
			{
				ipa: "oʊ",
				name: "goat"
			}
		]
	},
	{
		id: "marks",
		label: "Stress and syllable",
		phones: [
			{
				ipa: "ˈ",
				name: "primary stress, before the stressed syllable onset"
			},
			{
				ipa: "ˌ",
				name: "secondary stress"
			},
			{
				ipa: ".",
				name: "syllable boundary"
			}
		]
	}
];
var SINGING_EXTRAS = [
	{
		ipa: "ː",
		name: "vowel length — monophthongs only, note ≥ 2 beats"
	},
	{
		ipa: "‿",
		name: "tie across a note boundary"
	},
	{
		ipa: "a",
		name: "split half of aɪ / aʊ only — not a general vowel"
	}
];
var RAP_EXTRAS = [{
	ipa: "(",
	name: "elision mark, open"
}, {
	ipa: ")",
	name: "elision mark, close — (ə)"
}];
var FORBIDDEN = [
	{
		ipa: "ː",
		name: "length — banned in Speak and Rap"
	},
	{
		ipa: "ʰ",
		name: "aspiration — banned in every mode"
	},
	{
		ipa: "̩",
		name: "syllabic diacritic — banned in every mode"
	},
	{
		ipa: "g",
		name: "ASCII g — use script ɡ"
	},
	{
		ipa: "r",
		name: "ASCII r — use ɹ"
	}
];
var KNOWN_REJECTS = {
	"ː": "length mark ː",
	"ʰ": "aspiration ʰ",
	"̩": "syllabic diacritic ̩",
	g: "ASCII g (U+0067) — the inventory requires script ɡ U+0261",
	r: "ASCII r — the inventory requires ɹ",
	R: "ASCII R — the inventory requires ɹ",
	"ɜ": "ɜ — use ɝ for rhotic nurse, not ɜ or ɜɹ",
	"ɐ": "ɐ is outside the inventory",
	"ɾ": "flap ɾ is outside the inventory",
	"ʔ": "glottal stop ʔ is outside the inventory",
	":": "ASCII colon — not a length mark, and ː is forbidden outside singing",
	"(": "elision parentheses are a Rap-only mark",
	")": "elision parentheses are a Rap-only mark",
	"‿": "tie ‿ is a Singing-only mark",
	a: "bare a is not a vowel in this inventory",
	" ": "space — separate syllables with . not spaces",
	"'": "ASCII apostrophe — stress is ˈ or ˌ",
	"ˈ": "primary stress",
	"ˌ": "secondary stress"
};
function symbolsFor(mode) {
	const symbols = /* @__PURE__ */ new Set([
		...CONSONANTS,
		...VOWELS,
		...DIPHTHONGS,
		...STRESS,
		"."
	]);
	if (mode === "singing") {
		symbols.add("ː");
		symbols.add("‿");
		symbols.add("a");
	}
	if (mode === "rap") {
		symbols.add("(");
		symbols.add(")");
	}
	return [...symbols].sort((a, b) => b.length - a.length || a.localeCompare(b));
}
function tokenize(input, mode) {
	const symbols = symbolsFor(mode);
	const tokens = [];
	let i = 0;
	while (i < input.length) {
		let matched = "";
		for (const symbol of symbols) if (input.startsWith(symbol, i)) {
			matched = symbol;
			break;
		}
		if (matched) {
			tokens.push({
				kind: "phone",
				value: matched
			});
			i += matched.length;
			continue;
		}
		const cp = input.codePointAt(i) ?? 0;
		const ch = String.fromCodePoint(cp);
		const named = KNOWN_REJECTS[ch];
		const detail = named ? `${named} (${codepoint(ch)})` : `character ${codepoint(ch)} ‘${ch}’ is outside the declared inventory`;
		tokens.push({
			kind: "bad",
			value: ch,
			detail
		});
		i += ch.length;
	}
	return tokens;
}
function codepoint(text) {
	return [...text].map((ch) => {
		return "U+" + (ch.codePointAt(0) ?? 0).toString(16).toUpperCase().padStart(4, "0");
	}).join(" ");
}
function modeLabel(mode) {
	if (mode === "g2p") return "Speak";
	if (mode === "singing") return "Sing";
	return "Rap";
}
var FLAG_SPEC = {
	g2p: {
		OOV: "bare",
		UNCERTAIN: "bare",
		ALT: "value",
		POS: "value",
		RP: "bare",
		MULTIWORD: "bare"
	},
	singing: {
		OOV: "bare",
		UNCERTAIN: "bare",
		ELISION: "value",
		CONSONANT_PLACEMENT: "value",
		MELISMA_RISK: "bare",
		STRESS_CONFLICT: "bare"
	},
	rap: {
		OOV: "bare",
		UNCERTAIN: "bare",
		METER_FIT: "value",
		STRESS_SHIFT: "bare",
		HOMOPHONE_RHYME: "value",
		DIALECT: "value"
	}
};
var VAGUE_DIALECT = /* @__PURE__ */ new Set([
	"non-standard",
	"nonstandard",
	"other",
	"dialect",
	"regional",
	"unknown",
	"various",
	"n/a"
]);
var REQUIRED_KEYS = {
	g2p: [
		"INVENTORY_VIOLATIONS",
		"OOV_COUNT",
		"UNCERTAIN_COUNT",
		"ALT_COUNT",
		"POS_COLLISIONS"
	],
	singing: [
		"INVENTORY_VIOLATIONS",
		"OOV_COUNT",
		"UNCERTAIN_COUNT",
		"ELISION_COUNT",
		"MELISMA_RISK_COUNT",
		"NOTE_TOTAL_CHECK"
	],
	rap: [
		"INVENTORY_VIOLATIONS",
		"OOV_COUNT",
		"UNCERTAIN_COUNT",
		"DIALECT_COUNT",
		"RHYME_CLASS_COLLISIONS",
		"ELISION_COVERAGE"
	]
};
var PROSE_KEYS = /* @__PURE__ */ new Set([
	"POS_COLLISIONS",
	"NOTE_TOTAL_CHECK",
	"RHYME_CLASS_COLLISIONS"
]);
function columnsFor(mode) {
	if (mode === "g2p") return 3;
	if (mode === "singing") return 4;
	return 5;
}
function splitFlags(field) {
	const trimmed = field.trim();
	if (!trimmed || trimmed === "-") return [];
	return trimmed.split(",").map((part) => {
		const raw = part.trim();
		const body = raw.startsWith("#") ? raw.slice(1) : raw;
		const colon = body.indexOf(":");
		if (colon === -1) return {
			raw,
			name: body
		};
		return {
			raw,
			name: body.slice(0, colon),
			value: body.slice(colon + 1)
		};
	}).filter((flag) => flag.name.length > 0);
}
function hasFlag(flags, name) {
	return flags.some((flag) => flag.name === name);
}
function syllableCount(phonemes) {
	const trimmed = phonemes.trim();
	if (!trimmed || trimmed === "?" || trimmed === "-") return 0;
	return trimmed.split(".").map((part) => part.trim()).filter(Boolean).length;
}
function phoneFindings(text, mode, line, where, beats, melisma) {
	const trimmed = text.trim();
	if (!trimmed || trimmed === "?" || trimmed === "-" || trimmed === "∅") return [];
	const tokens = tokenize(trimmed, mode);
	const findings = [];
	tokens.forEach((token, index) => {
		if (token.kind === "bad") {
			findings.push({
				severity: "block",
				code: "INV",
				line,
				message: `${where}: ${token.detail}`
			});
			return;
		}
		if (token.value !== "ː" && token.value !== "a" && token.value !== "ə") return;
		const prev = tokens[index - 1];
		const next = tokens[index + 1];
		if (token.value === "ː") {
			if (where !== "notes") {
				findings.push({
					severity: "block",
					code: "LENGTH",
					line,
					message: "ː is only legal inside a singing note segment, on a monophthong held at least 2 beats"
				});
				return;
			}
			const prevValue = prev?.kind === "phone" ? prev.value : void 0;
			if (!prevValue || !MONOPHTHONGS.has(prevValue)) findings.push({
				severity: melisma ? "warn" : "block",
				code: "LENGTH",
				line,
				message: melisma ? "ː does not follow a monophthong. Melisma is flagged — confirm the coloration is the one you want." : "ː must follow a monophthong. A diphthong needs #MELISMA_RISK and the coloration written in the segment."
			});
			else if (beats != null && beats < 2) findings.push({
				severity: "block",
				code: "LENGTH",
				line,
				message: `ː on a ${beats}-beat note — length is only for a hold of at least 2 beats`
			});
		}
		if (token.value === "a" && mode === "singing") {
			if (!(prev?.kind === "phone" && prev.value === "‿" || next?.kind === "phone" && next.value === "‿") && !melisma) findings.push({
				severity: "warn",
				code: "BARE_A",
				line,
				message: "Bare a is only a tie-split of aɪ or aʊ. It is not a general vowel."
			});
		}
		if (token.value === "ə" && next?.kind === "phone" && next.value === "ɹ") findings.push({
			severity: "warn",
			code: "RHOTIC",
			line,
			message: "Sequence əɹ. The inventory note says use ɚ or ɝ, not əɹ."
		});
	});
	return findings;
}
function parseNotes(field) {
	const trimmed = field.trim();
	if (!trimmed || trimmed === "?" || trimmed === "-") return { segments: [] };
	const re = /(\d+):([^:]+):(\d+(?:\.\d+)?)/g;
	const segments = [];
	let last = 0;
	let match;
	while (match = re.exec(trimmed)) {
		const between = trimmed.slice(last, match.index);
		if (between && !/^[\s;|,]+$/.test(between)) return {
			segments,
			error: `Note alignment breaks near “${between.trim()}”`
		};
		segments.push({
			phones: match[2],
			beats: Number(match[3])
		});
		last = match.index + match[0].length;
	}
	const tail = trimmed.slice(last);
	if (tail && !/^[\s;|,]+$/.test(tail)) return {
		segments,
		error: `Note alignment has a tail the bench cannot read: “${tail.trim()}”`
	};
	if (segments.length === 0) return {
		segments,
		error: "Note alignment must look like 1:kæt:1;2:s:0.5"
	};
	return { segments };
}
function parseHints(text, mode) {
	const hints = /* @__PURE__ */ new Map();
	for (const line of text.split(/\r?\n/)) {
		const trimmed = line.trim();
		if (!trimmed || trimmed.startsWith("#")) continue;
		const [rawWord, ...rest] = trimmed.split("	");
		const word = rawWord.trim().toLowerCase();
		if (!word) continue;
		const extra = rest.join("	").trim();
		const hint = {};
		if (mode === "g2p" && extra) hint.pos = extra;
		if (mode === "singing" && extra && /^[\d.\s,+/]+$/.test(extra)) {
			const beats = extra.split(/[\s,+/]+/).filter(Boolean).map(Number);
			if (beats.length > 0 && beats.every((n) => Number.isFinite(n))) hint.beats = beats;
		}
		hints.set(word, hint);
	}
	return hints;
}
function listWords(text) {
	return text.split(/\r?\n/).map((line) => line.trim()).filter((line) => line && !line.startsWith("#")).map((line) => line.split("	")[0]?.trim() ?? "").filter(Boolean);
}
function validationStart(line) {
	const trimmed = line.trim();
	if (trimmed === "#VALIDATION") return true;
	return /^#(INVENTORY_VIOLATIONS|OOV_COUNT|UNCERTAIN_COUNT|ALT_COUNT|POS_COLLISIONS|ELISION_COUNT|MELISMA_RISK_COUNT|NOTE_TOTAL_CHECK|DIALECT_COUNT|RHYME_CLASS_COLLISIONS|ELISION_COVERAGE)\b/.test(trimmed);
}
function emptyStats() {
	return {
		entries: 0,
		inventoryViolations: 0,
		oov: 0,
		uncertain: 0,
		alt: 0,
		elision: 0,
		melisma: 0,
		dialect: 0,
		multisyllabic: 0,
		elidedMultisyllabic: 0,
		elisionCoverage: null,
		validationPresent: false
	};
}
function finish(mode, findings, stats, probes) {
	const rank = {
		block: 0,
		warn: 1,
		note: 2
	};
	findings.sort((a, b) => rank[a.severity] - rank[b.severity] || (a.line ?? 0) - (b.line ?? 0));
	return {
		mode,
		findings,
		stats,
		probes,
		blocks: findings.filter((f) => f.severity === "block").length,
		warns: findings.filter((f) => f.severity === "warn").length
	};
}
function inspectRhyme(field, line) {
	const trimmed = field.trim();
	if (!trimmed || trimmed === "-" || trimmed === "?") return {
		findings: [],
		tags: []
	};
	const findings = [];
	const tags = [];
	for (const tag of trimmed.split(",").map((part) => part.trim()).filter(Boolean)) {
		const match = /^RC:([^:\s]+):([^:\s]+)$/.exec(tag);
		if (!match) {
			findings.push({
				severity: "block",
				code: "RHYME",
				line,
				message: `Rhyme class “${tag}” is not RC:<vowel-set>:<coda>. Open coda is ∅.`
			});
			continue;
		}
		tags.push(tag);
		if (match[1] !== "∅") findings.push(...phoneFindings(match[1], "rap", line, "rhyme", null, false));
		if (match[2] !== "∅") findings.push(...phoneFindings(match[2], "rap", line, "rhyme", null, false));
	}
	return {
		findings,
		tags
	};
}
function numbersMatch(declared, actual) {
	const value = Number(declared.trim());
	return Number.isFinite(value) && value === actual;
}
function coverageMatch(declared, actual) {
	const fraction = declared.trim().match(/^(\d+)\s*\/\s*(\d+)$/);
	const value = fraction ? Number(fraction[2]) === 0 ? NaN : Number(fraction[1]) / Number(fraction[2]) : Number(declared.trim());
	return Number.isFinite(value) && Math.abs(value - actual) <= .02;
}
function reviewLexicon(mode, output, words) {
	const findings = [];
	const probes = [];
	const stats = emptyStats();
	const text = output.replace(/^\uFEFF/, "").replace(/\r\n/g, "\n").replace(/\r/g, "\n");
	if (!text.trim()) {
		findings.push({
			severity: "note",
			code: "EMPTY",
			message: "Nothing to review yet. Load a sample, paste a lexicon, or transcribe the list."
		});
		return finish(mode, findings, stats, probes);
	}
	const hints = parseHints(words, mode);
	const lines = text.split("\n");
	let inValidation = false;
	const declared = {};
	const entries = [];
	const expected = columnsFor(mode);
	for (let index = 0; index < lines.length; index += 1) {
		const raw = lines[index] ?? "";
		const trimmed = raw.trim();
		if (!trimmed) continue;
		if (!inValidation && validationStart(trimmed)) {
			inValidation = true;
			stats.validationPresent = true;
		}
		if (inValidation) {
			if (trimmed === "#VALIDATION") continue;
			const key = /^#([A-Z0-9_]+)\s*:\s*(.*)$/.exec(trimmed);
			if (key) declared[key[1]] = key[2].trim();
			continue;
		}
		if (!raw.includes("	")) {
			findings.push({
				severity: "block",
				code: "FORMAT",
				line: index + 1,
				message: "Expected tab-separated columns. Spaces do not count."
			});
			continue;
		}
		const cols = raw.replace(/\t+$/g, "").split("	").map((col) => col.trim());
		if (cols.length !== expected) {
			findings.push({
				severity: "block",
				code: "FORMAT",
				line: index + 1,
				message: `${modeLabelColumns(mode)} needs ${expected} tab-separated columns; this line has ${cols.length}.`
			});
			continue;
		}
		if ((cols[0] ?? "").toLowerCase() === "word") continue;
		entries.push({
			line: index + 1,
			word: cols[0] ?? "",
			cols,
			flags: splitFlags(cols[expected - 1] ?? "")
		});
	}
	stats.entries = entries.length;
	if (entries.length === 0) findings.push({
		severity: "warn",
		code: "EMPTY",
		message: "No lexicon rows. The validation block, if any, has nothing under it."
	});
	const spec = FLAG_SPEC[mode];
	const byWord = /* @__PURE__ */ new Map();
	const rhymeOwners = /* @__PURE__ */ new Map();
	for (const entry of entries) {
		const key = entry.word.toLowerCase();
		const group = byWord.get(key) ?? [];
		group.push(entry);
		byWord.set(key, group);
		for (const flag of entry.flags) {
			const kind = spec[flag.name];
			if (!kind) {
				findings.push({
					severity: "warn",
					code: "FLAG",
					line: entry.line,
					message: `#${flag.name} is not a ${mode} flag.`
				});
				continue;
			}
			if (kind === "value" && !flag.value?.trim()) findings.push({
				severity: "warn",
				code: "FLAG",
				line: entry.line,
				message: `#${flag.name} needs a value after the colon.`
			});
			if (kind === "bare" && flag.value != null) findings.push({
				severity: "warn",
				code: "FLAG",
				line: entry.line,
				message: `#${flag.name} does not take a value.`
			});
		}
		if (hasFlag(entry.flags, "OOV")) stats.oov += 1;
		if (hasFlag(entry.flags, "UNCERTAIN")) stats.uncertain += 1;
		stats.alt += entry.flags.filter((flag) => flag.name === "ALT").length;
		stats.elision += entry.flags.filter((flag) => flag.name === "ELISION").length;
		if (hasFlag(entry.flags, "MELISMA_RISK")) stats.melisma += 1;
		if (hasFlag(entry.flags, "DIALECT")) stats.dialect += 1;
		const melisma = hasFlag(entry.flags, "MELISMA_RISK");
		const oov = hasFlag(entry.flags, "OOV");
		const phonemes = entry.cols[1] ?? "";
		if (oov) {
			const bad = [];
			if (phonemes.trim() !== "?") bad.push("phonemes");
			if (mode === "singing" && (entry.cols[2] ?? "").trim() !== "?") bad.push("note alignment");
			if (mode === "rap" && !["?", "-"].includes((entry.cols[2] ?? "").trim())) findings.push({
				severity: "warn",
				code: "OOV",
				line: entry.line,
				message: "OOV rap row should put ? in the rhyme column rather than a guessed class."
			});
			if (bad.length > 0) findings.push({
				severity: "block",
				code: "OOV_PHONES",
				line: entry.line,
				message: `#OOV must not carry a transcription. Put ? in ${bad.join(" and ")}.`
			});
		} else if (phonemes.trim() === "?") findings.push({
			severity: "block",
			code: "OOV_PHONES",
			line: entry.line,
			message: "Phoneme field is ? but the row has no #OOV flag."
		});
		if (mode === "g2p") {
			findings.push(...phoneFindings(phonemes, mode, entry.line, "phonemes", null, false));
			for (const flag of entry.flags) if (flag.name === "ALT" && flag.value) findings.push(...phoneFindings(flag.value, mode, entry.line, "alt", null, false));
			if (entry.word.includes("_") && !hasFlag(entry.flags, "MULTIWORD")) findings.push({
				severity: "warn",
				code: "MULTIWORD",
				line: entry.line,
				message: "Underscore marks a multiword entry. Add #MULTIWORD."
			});
			const hint = hints.get(key);
			if (hint?.pos && !hasFlag(entry.flags, "POS")) findings.push({
				severity: "warn",
				code: "POS",
				line: entry.line,
				message: `Word list supplied a POS hint (${hint.pos}) but the row has no #POS flag.`
			});
		}
		if (mode === "singing") {
			findings.push(...phoneFindings(phonemes, mode, entry.line, "syllables", null, melisma));
			if (!oov) {
				const parsed = parseNotes(entry.cols[2] ?? "");
				if (parsed.error) findings.push({
					severity: "block",
					code: "ALIGN",
					line: entry.line,
					message: parsed.error
				});
				let sum = 0;
				for (const segment of parsed.segments) {
					sum += segment.beats;
					findings.push(...phoneFindings(segment.phones, mode, entry.line, "notes", segment.beats, melisma));
				}
				const hint = hints.get(key);
				if (hint?.beats && parsed.segments.length > 0) {
					const expectedSum = hint.beats.reduce((total, beat) => total + beat, 0);
					if (Math.abs(sum - expectedSum) > .051) findings.push({
						severity: "block",
						code: "NOTE_SUM",
						line: entry.line,
						message: `Note durations sum to ${trimNum(sum)}, the word list asked for ${trimNum(expectedSum)}.`
					});
				}
				if (melisma) {
					if (!parsed.segments.some((segment) => /[ː‿a]/.test(segment.phones))) findings.push({
						severity: "warn",
						code: "MELISMA",
						line: entry.line,
						message: "#MELISMA_RISK is bare. Write the coloration in the note segment (a‿ɪ, aːɪ, or similar)."
					});
				}
			}
			for (const flag of entry.flags) {
				if (flag.name === "ELISION" && flag.value) findings.push(...phoneFindings(flag.value, mode, entry.line, "elision", null, melisma));
				if (flag.name === "CONSONANT_PLACEMENT" && flag.value && ![
					"onset",
					"offset",
					"split"
				].includes(flag.value)) findings.push({
					severity: "warn",
					code: "FLAG",
					line: entry.line,
					message: "#CONSONANT_PLACEMENT must be onset, offset, or split."
				});
			}
			if (hasFlag(entry.flags, "STRESS_CONFLICT")) findings.push({
				severity: "note",
				code: "STRESS",
				line: entry.line,
				message: "Stress conflict flagged. Speech stress stays in SYLLABLES — confirm the alignment did not quietly move ˈ."
			});
		}
		if (mode === "rap") {
			findings.push(...phoneFindings(phonemes, mode, entry.line, "phonemes", null, false));
			const rhyme = inspectRhyme(entry.cols[2] ?? "", entry.line);
			findings.push(...rhyme.findings);
			for (const tag of rhyme.tags) {
				const owners = rhymeOwners.get(tag) ?? [];
				owners.push(entry.word);
				rhymeOwners.set(tag, owners);
			}
			const elisionField = entry.cols[3] ?? "";
			const variants = elisionField.trim() && elisionField.trim() !== "-" && elisionField.trim() !== "?" ? elisionField.split(",").map((part) => part.trim()).filter(Boolean) : [];
			for (const variant of variants) findings.push(...phoneFindings(variant, mode, entry.line, "elision", null, false));
			const syllables = syllableCount(phonemes);
			if (syllables >= 2) {
				stats.multisyllabic += 1;
				if (variants.length > 0) stats.elidedMultisyllabic += 1;
			}
			for (const flag of entry.flags) {
				if (flag.name === "DIALECT") {
					const value = (flag.value ?? "").trim();
					if (!value || VAGUE_DIALECT.has(value.toLowerCase())) findings.push({
						severity: "warn",
						code: "DIALECT",
						line: entry.line,
						message: "#DIALECT needs a real variety (GA, AAVE, RP), not a vague label."
					});
				}
				if (flag.name === "METER_FIT") {
					const n = Number(flag.value);
					if (!Number.isInteger(n) || n < 1) findings.push({
						severity: "warn",
						code: "FLAG",
						line: entry.line,
						message: "#METER_FIT needs a positive integer."
					});
					else if (![syllables, ...variants.map((variant) => syllableCount(variant))].filter((c) => c > 0).includes(n)) findings.push({
						severity: "warn",
						code: "METER",
						line: entry.line,
						message: `#METER_FIT:${n} but none of the speech form or elisions is ${n} syllable${n === 1 ? "" : "s"}.`
					});
				}
				if (flag.name === "HOMOPHONE_RHYME" && !flag.value?.trim()) findings.push({
					severity: "warn",
					code: "FLAG",
					line: entry.line,
					message: "#HOMOPHONE_RHYME needs the other word."
				});
			}
		}
	}
	for (const [word, group] of byWord) {
		const posRows = group.filter((entry) => hasFlag(entry.flags, "POS"));
		const anyAlt = group.some((entry) => hasFlag(entry.flags, "ALT"));
		if (group.length >= 2 && posRows.length >= 2) findings.push({
			severity: "note",
			code: "POS",
			line: group[0]?.line,
			message: `POS collision on “${word}”. Confirm the first row is the more frequent reading.`
		});
		else if (mode === "g2p" && posRows.length > 0 && !anyAlt) findings.push({
			severity: "warn",
			code: "POS",
			line: posRows[0]?.line,
			message: "#POS is set but there is no #ALT and no second row. The other reading has to live somewhere."
		});
		else if (mode === "g2p" && group.length >= 2 && posRows.length === 0) findings.push({
			severity: "warn",
			code: "DUP",
			line: group[0]?.line,
			message: `“${word}” appears ${group.length} times with no #POS. Duplicate, or an untagged homograph?`
		});
	}
	if (mode === "rap" && stats.multisyllabic > 0) {
		stats.elisionCoverage = stats.elidedMultisyllabic / stats.multisyllabic;
		if (stats.elisionCoverage < .8) findings.push({
			severity: "warn",
			code: "ELISION",
			message: `Elision coverage is ${stats.elisionCoverage.toFixed(2)}. The gate is 0.8 of multisyllabic rows. The model is under-eliding.`
		});
	}
	for (const [tag, owners] of rhymeOwners) {
		const unique = [...new Set(owners)];
		if (unique.length < 2) continue;
		findings.push({
			severity: "note",
			code: "RHYME",
			message: `${tag} is shared by ${unique.join(", ")}. Confirm that collapse is intended — cot/caught must not merge in a dialect that keeps them apart.`
		});
	}
	let probesInBatch = 0;
	for (const probe of GATE0) {
		const rows = entries.filter((entry) => entry.word.toLowerCase() === probe.word);
		if (rows.length === 0) {
			probes.push({
				word: probe.word,
				expected: probe.ipa,
				actual: null,
				status: "absent",
				note: probe.note
			});
			continue;
		}
		probesInBatch += 1;
		const actual = (rows[0]?.cols[1] ?? "").trim();
		const status = actual === probe.ipa ? "match" : "diverge";
		probes.push({
			word: probe.word,
			expected: probe.ipa,
			actual,
			status,
			note: probe.note
		});
		if (status === "diverge") findings.push({
			severity: "note",
			code: "GATE0",
			line: rows[0]?.line,
			message: `Gate 0: “${probe.word}” is ${actual || "∅"} here; the reference is ${probe.ipa}. ${probe.note}`
		});
	}
	if (entries.length > 0 && probesInBatch === 0) findings.push({
		severity: "note",
		code: "GATE0",
		message: "Gate 0 not exercised. Drop in the, of, and, to, a, in, is, you, that, it, he, was, for, on, are, as, with, his, they, I."
	});
	if (!stats.validationPresent) findings.push({
		severity: "block",
		code: "VAL_MISSING",
		message: "No #VALIDATION block. The prompt requires one, and a batch without it is not acceptable."
	});
	else {
		stats.inventoryViolations = findings.filter((f) => f.code === "INV").length;
		for (const key of REQUIRED_KEYS[mode]) {
			if (!(key in declared)) {
				findings.push({
					severity: "warn",
					code: "VAL_KEY",
					message: `Validation block is missing #${key}.`
				});
				continue;
			}
			if (PROSE_KEYS.has(key)) continue;
			const claimed = declared[key] ?? "";
			if (key === "INVENTORY_VIOLATIONS") {
				if (!numbersMatch(claimed, stats.inventoryViolations)) findings.push({
					severity: "block",
					code: "VAL_DRIFT",
					message: `#INVENTORY_VIOLATIONS says ${claimed || "∅"}; the bench counts ${stats.inventoryViolations}. Do not accept the batch.`
				});
				continue;
			}
			if (key === "ELISION_COVERAGE") {
				if (stats.elisionCoverage != null && !coverageMatch(claimed, stats.elisionCoverage)) findings.push({
					severity: "warn",
					code: "VAL_DRIFT",
					message: `#ELISION_COVERAGE says ${claimed}; the bench gets ${stats.elisionCoverage.toFixed(2)}.`
				});
				continue;
			}
			const actual = countForKey(key, stats);
			if (actual != null && !numbersMatch(claimed, actual)) findings.push({
				severity: "warn",
				code: "VAL_DRIFT",
				message: `#${key} says ${claimed}; the bench counts ${actual}.`
			});
		}
	}
	if (!stats.validationPresent) stats.inventoryViolations = findings.filter((f) => f.code === "INV").length;
	return finish(mode, findings, stats, probes);
}
function countForKey(key, stats) {
	if (key === "OOV_COUNT") return stats.oov;
	if (key === "UNCERTAIN_COUNT") return stats.uncertain;
	if (key === "ALT_COUNT") return stats.alt;
	if (key === "ELISION_COUNT") return stats.elision;
	if (key === "MELISMA_RISK_COUNT") return stats.melisma;
	if (key === "DIALECT_COUNT") return stats.dialect;
	return null;
}
function modeLabelColumns(mode) {
	if (mode === "g2p") return "Speak";
	if (mode === "singing") return "Sing";
	return "Rap";
}
function trimNum(value) {
	return Number.isInteger(value) ? String(value) : value.toFixed(2).replace(/0$/, "").replace(/\.0$/, "");
}
var BENCH = `BENCH CONTRACT (delivery):
- Raw UTF-8 text. No markdown fences. No prose before the first lexicon line.
- Tab characters between columns, never spaces.
- One lexicon entry per line, then a line exactly #VALIDATION, then the required count lines.
- Script g is ɡ (U+0261). The alveolar approximant is ɹ. Rhotic vowels are ɚ and ɝ.`;
var G2P_EXAMPLE = `WORKED EXAMPLE (format only — do not emit these unless they are in the input):
cat	kæt	-
strength	stɹɛŋθ	-
record	ˈɹɛ.kɚd	#POS:noun,#ALT:ɹɪ.ˈkɔɹd
Aureliax	?	#OOV`;
var SING_EXAMPLE = `WORKED EXAMPLE (format only — do not emit these unless they are in the input):
day	deɪ	1:d:0.5;2:e‿ɪ:2	-
father	ˈfɑ.ðɚ	1:ˈfɑː:2;2:ðɚ:1	-
Aureliax	?	?	#OOV`;
var RAP_EXAMPLE = `WORKED EXAMPLE (format only — do not emit these unless they are in the input):
every	ˈɛv.ə.ɹi	RC:i:∅	ˈɛv.ɹi	#METER_FIT:2
sing	ˈsɪŋ	RC:ɪ:ŋ,RC:ɪ:∅	-	-
police	pə.ˈlis	RC:i:s	ˈpoʊ.lis	#STRESS_SHIFT,#METER_FIT:2`;
function buildSystemPrompt(mode, workedExample) {
	if (mode === "g2p") return g2p(workedExample);
	if (mode === "singing") return singing(workedExample);
	return rap(workedExample);
}
function buildFullPrompt(mode, words, workedExample) {
	const list = words.trim() ? words.trim() : "(no word list yet)";
	return `${buildSystemPrompt(mode, workedExample)}

INPUT LIST:
${list}`;
}
function g2p(workedExample) {
	return `You are a phonetics specialist generating a machine-readable pronunciation lexicon for a TTS frontend. You do not guess. When you do not know a pronunciation, you say so using the required flags.

${INVENTORY_BLOCK}

INPUT: a word list, one per line (multiword entries joined by _). Optional per-line POS hint in a second column, tab-separated.
TARGET: English — General American default, flag RP divergence.
PHONE SET: IPA, restricted to the declared inventory.

OUTPUT FORMAT — one entry per line, tab-separated:
WORD<TAB>PHONEMES<TAB>FLAGS

- PHONEMES: IPA, syllables separated by ., primary stress ˈ before the stressed syllable's onset, secondary ˌ where applicable.
- FLAGS: zero or more below, comma-separated, or - if none.

REQUIRED FLAGS:
- #OOV — word not in reliable knowledge. DO NOT emit phonemes; emit ? in the phoneme field. Mandatory for names, novel coinages, loanwords you cannot confidently transcribe.
- #UNCERTAIN — best-guess pronunciation, low confidence. Phonemes emitted; reviewer should check.
- #ALT:<phonemes> — competing attested pronunciation. Primary in phoneme field, alternative here.
- #POS:<tag> — POS-specific reading (record noun vs verb, read present vs past).
- #RP — GA and RP diverge; phoneme field is GA.
- #MULTIWORD — multiword expression; phonemes span the whole phrase with . between words too.

RULES:
1. Transcribe to the declared inventory only. If a pronunciation would require a phone not in the inventory, treat as #OOV rather than substituting.
2. Never guess a proper noun. #OOV is correct for an unfamiliar name even if it "looks" pronounceable.
3. Homographs with POS-dependent readings: more frequent reading primary, other under #ALT:, tag #POS: on both if POS hints supplied.
4. Multiword entries: single phoneme string, . between words, stress marked normally.
5. Do not emit IPA if the caller's engine expects ARPAbet — this prompt is IPA-only. If ARPAbet is needed, stop and say so.
6. No pronunciation for a word you would not bet on. #OOV is cheap; a wrong transcription is expensive downstream.
7. NEVER emit ː, ʰ, or ̩. These are outside the inventory and their presence indicates an error.

VALIDATION PASS — required, output after the lexicon:
#VALIDATION
#INVENTORY_VIOLATIONS: <count>
<list any phones not in the declared inventory, with offending lines>
#OOV_COUNT: <count>
#UNCERTAIN_COUNT: <count>
#ALT_COUNT: <count>
#POS_COLLISIONS: <list any word with multiple POS-tagged entries and confirm the primary is the more frequent reading>

If #INVENTORY_VIOLATIONS is nonzero, re-emit the offending lines with corrected phonemes or downgraded to #OOV.

${BENCH}
${workedExample ? `\n${G2P_EXAMPLE}\n` : ""}`;
}
function singing(workedExample) {
	return `You are a phonetics specialist generating a SINGING pronunciation lexicon for a singing voice synthesizer. Input is a word list with optional melody hints (note durations in beats, comma-separated in a second tab-separated column). Output is IPA phonemes aligned to musical notes, with vowel elongation and consonant placement specified.

${INVENTORY_BLOCK}

The shared ban on ː is lifted only for the case below. ʰ and ̩ stay forbidden.

ADDITIONAL MARKS (this task only):
- ː vowel length — only on monophthongs, only when a note is sustained ≥ 2 beats. Not on diphthongs, except as documented melisma coloration under #MELISMA_RISK.
- ‿ tie — between phonemes sung across a note boundary, e.g. a‿ɪ.
- Bare a is legal only as a tie-split or melisma coloration of aɪ / aʊ. It is not otherwise a vowel in this inventory.

OUTPUT FORMAT — tab-separated:
WORD<TAB>SYLLABLES<TAB>NOTE_ALIGNMENT<TAB>FLAGS

- SYLLABLES: IPA with . between syllables, stress marked. Speech form. No ː in this column.
- NOTE_ALIGNMENT: one segment per note, format NOTE_INDEX:PHONEMES:DURATION_BEATS, segments separated by ; . Example: 1:kæ:1;2:t:0.5. Consonants belonging to the next note's onset are written at the start of that note's segment.
- FLAGS: as below, or - if none.

REQUIRED FLAGS:
- #OOV — unknown word, emit ? in the syllables field and ? in the alignment field.
- #UNCERTAIN — low confidence.
- #ELISION:<variant> — sung contraction exists (ev'ry, o'er, 'tis). Primary is full form, variant is sung form.
- #CONSONANT_PLACEMENT:<onset|offset|split> — for final clusters (strengths), where the cluster sits relative to the note boundary.
- #MELISMA_RISK — diphthong or vowel that, if sustained across notes, requires documented coloration (e.g. aɪ sustained → aːɪ or aɪə). Note chosen coloration in the segment.
- #STRESS_CONFLICT — supplied melody places a note on a syllable unstressed in speech. Emit speech stress in SYLLABLES and note melodic stress in the alignment field.

RULES:
1. Default vowel length unmarked. Add ː only when a note's duration ≥ 2 beats and the vowel is monophthongal.
2. Diphthongs sung across a note boundary: split with ‿, e.g. a‿ɪ.
3. Consonants assigned to the note of the syllable they begin, unless the caller's engine requires offset placement — if so, say so and re-emit.
4. Do not re-stress a word to fit the melody. Emit #STRESS_CONFLICT and let the caller decide.
5. #OOV remains mandatory; a wrong singing transcription is worse than a refusal because timing errors compound.
6. NEVER emit ʰ or ̩.
7. NOTE_ALIGNMENT is a candidate. The caller reconciles it with a deterministic aligner against the supplied durations. Still make the durations sum to the supplied melody.

VALIDATION PASS — required:
#VALIDATION
#INVENTORY_VIOLATIONS: <count>
<list any phones not in the declared inventory, with offending lines>
#OOV_COUNT: <count>
#UNCERTAIN_COUNT: <count>
#ELISION_COUNT: <count>
#MELISMA_RISK_COUNT: <count>
#NOTE_TOTAL_CHECK: <sum of durations per word; confirm matches supplied melody>

${BENCH}
${workedExample ? `\n${SING_EXAMPLE}\n` : ""}`;
}
function rap(workedExample) {
	return `You are a phonetics specialist generating a RAP PERFORMANCE lexicon. Input is a word list with optional meter hints (target syllable count, or a stress skeleton like xXxX) in a second tab-separated column. Output is IPA with default speech stress, elision variants, and rhyme-class tags for assonance and consonance matching.

${INVENTORY_BLOCK}

ADDITIONAL MARK (this task only):
- ( ) elision mark — e.g. (ə) for optional schwa. Parentheses are allowed. ː, ʰ, and ̩ are not.

OUTPUT FORMAT — tab-separated:
WORD<TAB>PHONEMES<TAB>RHYME_CLASS<TAB>ELISIONS<TAB>FLAGS

- PHONEMES: IPA with . syllable boundaries and ˈ/ˌ for default speech stress.
- RHYME_CLASS: one or more tags RC:<vowel-set>:<coda-class>, comma-separated. Example: RC:ɪ:ŋ for "sing" (rhymes with ring, thing, king by assonance+coda), and RC:ɪ:∅ (open) by assonance alone. ∅ means an open coda.
- ELISIONS: comma-separated attested performance variants, e.g. ˈɛv.ɹi,ˈɛv.ə.ɹi for "every". Use - if the word is monosyllabic and has no variant.

REQUIRED FLAGS:
- #OOV — unknown word. Emit ? in the phoneme field. Do not invent a rhyme class for it; emit ? there too.
- #UNCERTAIN — low confidence.
- #METER_FIT:<n> — word can fill n syllables in performance (via elision or expansion), variants listed in ELISIONS.
- #STRESS_SHIFT — word commonly re-stressed in rap performance to fit meter (e.g. police → ˈpoʊ.lis). Emit speech stress as primary, note the shift in ELISIONS or the flag.
- #HOMOPHONE_RHYME:<word> — rhymes with a different word whose rhyme class differs from what spelling suggests; flag dialect dependence.
- #DIALECT:<GA|AAVE|RP|...> — pronunciation is dialect-dependent; emit GA default, note alternatives. Name a real variety. Never "non-standard".

RULES:
1. ELISIONS is not optional filler — it is the point. Every word with ≥ 2 syllables gets at least one elision variant where a performer would plausibly compress it.
2. Rhyme classes are PERFORMANCE classes, not dictionary rhymes. Two words with different codas but assonant nuclei and matching stress are rhyme-class compatible; the tag format captures both dimensions.
3. Stress marks in PHONEMES are SPEECH stress. Do not silently re-stress to fit a meter; use #STRESS_SHIFT.
4. Dialect sensitivity: AAVE and Southern US rap pronunciation diverge from GA in ways that matter for rhyme (-ing → -in, monophthongization, coda deletion). If you cannot attribute a variant to a dialect with confidence, omit rather than guess. Do not emit ː for monophthongization; this inventory forbids the length mark — describe the dialect in #DIALECT and give the inventory-legal vowel in ELISIONS.
5. #OOV remains mandatory.
6. NEVER emit ː, ʰ, or ̩.
7. The RC:<vowel-set>:<coda-class> scheme is a working invention (lexicon v1.0), not a published standard. Apply it consistently inside the batch.

VALIDATION PASS — required:
#VALIDATION
#INVENTORY_VIOLATIONS: <count>
<list any phones not in the declared inventory, with offending lines>
#OOV_COUNT: <count>
#UNCERTAIN_COUNT: <count>
#DIALECT_COUNT: <count>
#RHYME_CLASS_COLLISIONS: <words sharing a class — confirm intended>
#ELISION_COVERAGE: <fraction of multisyllabic entries with ≥ 1 elision variant>

${BENCH}
${workedExample ? `\n${RAP_EXAMPLE}\n` : ""}`;
}
//#endregion
export { buildFullPrompt as a, listWords as c, SINGING_EXTRAS as i, modeLabel as l, PHONE_GROUPS as n, buildSystemPrompt as o, RAP_EXTRAS as r, codepoint as s, FORBIDDEN as t, reviewLexicon as u };

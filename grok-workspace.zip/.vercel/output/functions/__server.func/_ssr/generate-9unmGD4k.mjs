import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { c as listWords, o as buildSystemPrompt } from "./prompts-B2AB_1QV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/generate-9unmGD4k.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function readInput(input) {
	if (!input || typeof input !== "object") return { error: "Bad request." };
	const value = input;
	const mode = value.mode;
	if (mode !== "g2p" && mode !== "singing" && mode !== "rap") return { error: "Unknown lexicon mode." };
	if (typeof value.words !== "string") return { error: "Word list missing." };
	if (value.words.length > 8e3) return { error: "Word list is too long." };
	const rows = listWords(value.words);
	if (rows.length === 0) return { error: "The word list is empty." };
	if (rows.length > 40) return { error: `Batch cap is 40 lines. Past that, use a rule-based G2P and the model only on the OOV tail.` };
	return {
		mode,
		words: value.words,
		workedExample: value.workedExample !== false
	};
}
function stripFences(text) {
	return (text.match(/```(?:[a-zA-Z]+)?\n([\s\S]*?)```/)?.[1] ?? text).trim();
}
var generateLexicon_createServerFn_handler = createServerRpc({
	id: "d39f36c3c16a9784b10ce67070668c4cf1dbdd5b7d8bc49c1500fbd6f689c4c1",
	name: "generateLexicon",
	filename: "src/lib/lexicon/generate.ts"
}, (opts) => generateLexicon.__executeServer(opts));
var generateLexicon = createServerFn({ method: "POST" }).validator((input) => input).handler(generateLexicon_createServerFn_handler, async ({ data }) => {
	const parsed = readInput(data);
	if ("error" in parsed) return {
		ok: false,
		error: parsed.error
	};
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "Transcription is unavailable in this environment. Paste a lexicon and review it anyway."
	};
	const system = buildSystemPrompt(parsed.mode, parsed.workedExample);
	const user = `INPUT LIST (${listWords(parsed.words).length} lines). Output lexicon lines, then the validation block. No markdown fences. No preamble.\n\n${parsed.words.trim()}`;
	let response;
	try {
		response = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			signal: AbortSignal.timeout(55e3),
			body: JSON.stringify({
				model: "grok-4.5",
				temperature: .2,
				max_tokens: 4096,
				messages: [{
					role: "system",
					content: system
				}, {
					role: "user",
					content: user
				}]
			})
		});
	} catch {
		return {
			ok: false,
			error: "The transcription call did not complete. Try a shorter list."
		};
	}
	if (!response.ok) return {
		ok: false,
		error: `Transcription failed (${response.status}). Nothing was changed.`
	};
	const text = stripFences((await response.json()).choices?.[0]?.message?.content ?? "");
	if (!text) return {
		ok: false,
		error: "The model returned an empty lexicon."
	};
	return {
		ok: true,
		text
	};
});
//#endregion
export { generateLexicon_createServerFn_handler };
